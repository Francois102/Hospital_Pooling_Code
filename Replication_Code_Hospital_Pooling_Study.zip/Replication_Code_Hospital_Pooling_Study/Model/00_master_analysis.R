
#Set working directory

 setwd("/Users/francoisdaudelin/Desktop/Model/Replication_Code_Hospital_Pooling_Study")

print("Starting analysis pipeline...")
print(paste("Working directory:", getwd()))
# Step 1: Load all required libraries
print("Loading libraries...")
source("Model/01_load_libraries.R")

# Step 2: Import and process data
print("Importing and processing data...")
source("Model/02_import_data.R")

# Step 3: Run regression analysis
print("Running regression analysis...")
source("Model/03_regression_analysis.R")

# Step 4: Run volatility analysis
print("Running volatility analysis...")
source("Model/04_volatility_analysis.R")

# Step 5: Run temporal clustering analysis
print("Running temporal clustering analysis...")
source("Model/05_temporal_clustering.R")

# Step 6: Run health effects analysis
print("Running health effects analysis...")
source("Model/06_health_effects.R")

# Step 7: Generate all figures
print("Generating figures...")
source("Model/07_generate_figures.R")

# Step 8: Save session info for reproducibility
writeLines(capture.output(sessionInfo()), "session_info.txt")

print("========================================")
print("All analyses complete!")
print("Figures saved to /Figures directory")
print("Results saved to /Results directory")
print("Session info saved to session_info.txt")
print("========================================")
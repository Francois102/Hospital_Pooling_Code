# Import and process data for all analyses

############################################################
# Dataframe Descriptions
#
# Hosp_demand   : Time series of hospital admissions per 100,000 population at the HSA level
# ICU_demand    : Time series of cumulative weekly ICU patient-days at the HSA level
#                 (e.g., 3 patients over 7 days = 21 patient-days)
# ICU_occ       : Time series of weekly average ICU occupancy (fraction) at the HSA level
# Capacity      : Time series of weekly cumulative ICU beds available at the HSA level 
#                 (e.g., 2 beds over 7 days = 14 bed-days)
############################################################
############################################################
# Variables Created in HSA_df dataframe 
#
# HSA                 : Health Service Area identifier number
# Population          : Total population of the HSA
# facilities          : Number of healthcare facilities in the HSA
# Income              : Population-weighted average income per capita
# Area                : Total square miles of the HSA
# Density             : Population density (Population / Area)
# Over60              : Proportion of population aged 60 and over

# Maximum ICU Occupancy (% of capacity)
# max_est_Delta       : Maximum estimated % ICU occupancy during Delta (weekly)
# max_est_Omicron     : Maximum estimated % ICU occupancy during Omicron (weekly)
# max_est_w2          : Maximum estimated % ICU occupancy during Winter 2020 (weekly)
#
# ICU Capacity (beds per 100,000 population)
#
# CapDelta            : ICU capacity at Delta peak 
# CapOmicron          : ICU capacity at Omicron peak
# Capw2               : ICU capacity at Winter 2020 peak
#
# Peak Timing
#
# Peak_Delta          : Date of maximum ICU occupancy during Delta
# Peak_Omicron        : Date of maximum ICU occupancy during Omicron
# Peak_w2             : Date of maximum ICU occupancy during Winter 2020
#
# Cumulative Hospitalizations (per 100,000)
#
# Cumul_Delta         : Cumulative hospitalizations during Delta wave
# Cumul_Omicron       : Cumulative hospitalizations during Omicron wave
# Cumul_w2            : Cumulative hospitalizations during Winter 2020 wave
# Cumul_Delta_4w      : Hospitalizations in 4 weeks around Delta peak
# Cumul_Omicron_4w    : Hospitalizations in 4 weeks around Omicron peak
# Cumul_w2_4w         : Hospitalizations in 4 weeks around Winter 2020 peak
#
# Volatility Measures
#
# stdv_ICU_Delta      : Volatility of ICU occupancy during Delta
# stdv_ICU_Omicron    : Volatility of ICU occupancy during Omicron
# stdv_ICU_w2         : Volatility of ICU occupancy during Winter 2020
# jump_delta          : Maximum week-to-week change in ICU occupancy during Delta
# jump_omicron        : Maximum week-to-week change during Omicron
# jump_wave2          : Maximum week-to-week change during Winter 2020
#
#
# Vaccination Rates (%)
#
# Vaccination_Delta               : % population with ≥1 dose at Delta peak
# Vaccination_Omicron             : % population with ≥1 dose at Omicron peak
# Avg_Vaccination_Delta_Period    : Average vaccination rate during Delta wave period
#
############################################################


# Import base data
print("Loading county and facility data...")
County <- import("Data/Data_County.xlsx")
All_Facilities<-import("Data/Data_Facility_TS.csv")
Vaccination <- import(file="Data/VaccinationRates.csv")


# Process facility data
All_Facilities <- All_Facilities %>% 
  mutate(collection_week = as.Date(collection_week,'%Y/%m/%d')) %>% 
  select(collection_week, hospital_pk, fips_code,
         staffed_icu_adult_patients_confirmed_covid_7_day_sum,
         total_adult_patients_hospitalized_confirmed_covid_7_day_sum,
         total_staffed_adult_icu_beds_7_day_sum, hospital_name) %>% 
  rename(ICU_admissions = staffed_icu_adult_patients_confirmed_covid_7_day_sum,
         Hosp_admissions = total_adult_patients_hospitalized_confirmed_covid_7_day_sum,
         Bed_sum = total_staffed_adult_icu_beds_7_day_sum)

# Handle censored data
All_Facilities <- All_Facilities %>%
  group_by(hospital_pk) %>%
  arrange(collection_week, hospital_pk) %>% 
  mutate(
    ICU_admissions = case_when(
      ICU_admissions > 0 ~ ICU_admissions, 
      ICU_admissions < 0 ~ 2,
      TRUE ~ NA_real_),
    Hosp_admissions = case_when(
      Hosp_admissions > 0 ~ Hosp_admissions, 
      Hosp_admissions < 0 ~ 2,
      TRUE ~ NA_real_),
    Bed_sum = case_when(
      Bed_sum > 0 ~ Bed_sum, 
      Bed_sum < 0 ~ 2,
      TRUE ~ NA_real_)) %>% 
  ungroup()

# Create HSA dataframe
HSA_df <- data.frame(HSA = unique(County$HSA), Population = NA, facilities = NA)

# Initialize time series dataframes
date_seq_weekly <- seq.Date(from=as.Date("2020-06-28"), to=as.Date("2022-12-11"), "weeks")
date_seq_daily <- seq.Date(from=as.Date("2020/06/01"), to=as.Date("2022-12-11"), "days")

ICU_demand <- data.frame(Date = date_seq_weekly)
Hosp_demand <- data.frame(Date = date_seq_weekly)
ICU_occ <- data.frame(Date = date_seq_weekly)
Capacity <- data.frame(Date = date_seq_weekly)

print("Processing HSA-level data...")

# Process each HSA
for(o in 1:dim(HSA_df)[1]) {
  Filter <- County %>% 
    filter(HSA == HSA_df[o,1]) %>% 
    select(Population, `Income per Capita`, `Square Miles`, FIPS, County, `Proportion 60 and over`)
  
  # Calculate facilities count
  n <- All_Facilities %>% 
    filter(fips_code %in% Filter$FIPS) %>% 
    summarise(count = n_distinct(hospital_pk)) %>% 
    pull(count)
  
  # Calculate HSA demographics
  Population_HSA <- sum(Filter$Population)
  Area_HSA <- sum(Filter$`Square Miles`)
  Income_HSA <- round(sum((Filter$Population * Filter$`Income per Capita`))/Population_HSA)
  Over65_HSA <- round(sum((Filter$Population * Filter$`Proportion 60 and over`))/Population_HSA, digits=2)
  
  # Store in HSA_df
  HSA_df$Population[o] <- Population_HSA
  HSA_df$facilities[o] <- n
  HSA_df$Income[o] <- Income_HSA
  HSA_df$Area[o] <- Area_HSA
  HSA_df$Density[o] <- Population_HSA/Area_HSA
  HSA_df$Over60[o] <- Over65_HSA
  
  # Aggregate facility data at HSA level
  Cumulative_TS <- All_Facilities %>% 
    filter(fips_code %in% Filter$FIPS) %>% 
    group_by(collection_week) %>%
    summarise(
      adm_icu_sum = sum(ICU_admissions, na.rm = TRUE),
      adm_hosp_sum = sum(Hosp_admissions, na.rm = TRUE),
      total_icu_beds_sum = sum(Bed_sum, na.rm = TRUE)) %>% 
    mutate(weekly_sum_ICU = adm_icu_sum,
           weekly_sum_Hosp = adm_hosp_sum) %>%
    arrange(collection_week)
  
  new_name <- paste("HSA", HSA_df[o,1], sep="")
  
  # Update time series dataframes
  ICU_demand <- ICU_demand %>% 
    mutate(HSA = Cumulative_TS$weekly_sum_ICU[match(ICU_demand$Date, Cumulative_TS$collection_week)])
  Hosp_demand <- Hosp_demand %>% 
    mutate(HSA = Cumulative_TS$weekly_sum_Hosp[match(ICU_demand$Date, Cumulative_TS$collection_week)])
  Capacity <- Capacity %>%
    mutate(HSA = if_else(
      Cumulative_TS$total_icu_beds_sum[match(ICU_demand$Date, Cumulative_TS$collection_week)] == 0,
      NA_real_,
      Cumulative_TS$total_icu_beds_sum[match(ICU_demand$Date, Cumulative_TS$collection_week)]))
  ICU_occ <- ICU_occ %>% 
    mutate(HSA = ICU_demand$HSA/Capacity$HSA)
  
  # Rename columns
  ICU_demand <- ICU_demand %>% rename(!!new_name := HSA)
  Hosp_demand <- Hosp_demand %>% 
    mutate(HSA = HSA/Population_HSA*100000) %>% 
    rename(!!new_name := HSA)
  Capacity <- Capacity %>% rename(!!new_name := HSA)
  ICU_occ <- ICU_occ %>% rename(!!new_name := HSA)
}

print("Processing wave-specific metrics...")

# Add wave-specific columns to HSA_df
HSA_df <- HSA_df %>% 
  mutate(
    max_occ_Delta = NA, max_occ_Omicron = NA, max_occ_w2 = NA,
    Cumul_Delta = NA, Cumul_w2 = NA, Cumul_Omicron = NA,
    Cumul_Delta_4w = NA, Cumul_w2_4w = NA, Cumul_Omicron_4w = NA,
    Peak_Delta = as.Date(NA), Peak_w2 = as.Date(NA), Peak_Omicron = as.Date(NA),
    stdv_ICU_Delta = NA, stdv_ICU_Omicron = NA, stdv_ICU_w2 = NA,
    jump_delta = NA, jump_omicron = NA, jump_wave2 = NA,
    Vaccination_Delta = NA, Vaccination_Omicron = NA
  )

# Source helper function for wave calculations
source("Model/02a_wave_calculations.R")

print("Processing data for each COVID-19 wave...")
for (i in 1:dim(HSA_df)[1]) {
  HSA_numb<-HSA_df[i,1]
  HSA_name <- paste("HSA", HSA_df[i,1], sep="")  
  
    # Calculate wave-specific metrics
    calculate_wave_metrics(HSA_numb, HSA_name, ICU_occ, ICU_demand, 
                           Capacity, Hosp_demand,HSA_df)
    
  
}

# After the wave calculations are complete
print("Processing vaccination data...")

# Import vaccination data
Vaccination <- import(file="Data/VaccinationRates.csv")
Vaccination$Date <- as.Date(Vaccination$Date, '%m/%d/%Y')
Vaccination <- Vaccination %>% 
  filter(Date > as.Date("04/29/21", '%m/%d/%y'), 
         Date < as.Date("04/30/2022", '%m/%d/%Y'))
Vaccination$FIPS <- sub("^0+", "", Vaccination$FIPS)

# Calculate vaccination at peaks for each county
County <- calculate_vaccination_at_peaks(County, HSA_df, Vaccination)

# Aggregate to HSA level
HSA_df <- aggregate_vaccination_to_HSA(County, HSA_df)

print("Vaccination data processing complete")

# Save processed data
save(ICU_occ, file="Intermediate_outputs/ICU_occ.txt")
save(ICU_demand, file="Intermediate_outputs/ICU_demand.txt")
save(Capacity, file="Intermediate_outputs/Capacity.txt")
save(HSA_df, file="Intermediate_outputs/HSA_df.txt")
save(Hosp_demand, file="Intermediate_outputs/Hosp_demand.txt")

print("Data import and processing complete!")

# Function to create HSA example plots for temporal clustering figure
# This creates the bottom panel showing individual hospitals vs pooled

create_hsa_example_plots <- function(wave2_data, delta_data, omicron_data, HSA_example = 61) {
  
  # Get valid hospitals for each wave
  valid_hospitals_wave2 <- wave2_data %>%
    group_by(hospital_pk) %>%
    summarise(
      total_ICU_admissions = sum(ICU_admissions, na.rm = TRUE),
      weeks_with_positive_ICU_admissions = sum(ICU_admissions > 0, na.rm = TRUE),
      HSA = first(HSA),
      .groups = "drop"
    ) %>% 
    filter(total_ICU_admissions > 0, weeks_with_positive_ICU_admissions > 10) %>% 
    pull(hospital_pk)
  
  valid_hospitals_delta <- delta_data %>%
    group_by(hospital_pk) %>%
    summarise(
      total_ICU_admissions = sum(ICU_admissions, na.rm = TRUE),
      weeks_with_positive_ICU_admissions = sum(ICU_admissions > 0, na.rm = TRUE),
      HSA = first(HSA),
      .groups = "drop"
    ) %>% 
    filter(total_ICU_admissions > 0, weeks_with_positive_ICU_admissions > 10) %>% 
    pull(hospital_pk)
  
  valid_hospitals_omicron <- omicron_data %>%
    group_by(hospital_pk) %>%
    summarise(
      total_ICU_admissions = sum(ICU_admissions, na.rm = TRUE),
      weeks_with_positive_ICU_admissions = sum(ICU_admissions > 0, na.rm = TRUE),
      HSA = first(HSA),
      .groups = "drop"
    ) %>% 
    filter(total_ICU_admissions > 0, weeks_with_positive_ICU_admissions > 10) %>% 
    pull(hospital_pk)
  
  # ========================================
  # Winter 2020 Example
  # ========================================
  HSA_data_wave2 <- wave2_data %>% 
    filter(HSA == HSA_example, hospital_pk %in% valid_hospitals_wave2) %>%
    group_by(hospital_pk)
  
  processed_data_wave2 <- HSA_data_wave2 %>%
    group_by(hospital_pk) %>%
    mutate(
      ICU_occupancy = ICU_admissions/Bed_sum,
      .groups = "drop"
    ) %>% 
    filter(!is.na(ICU_occupancy))
  
  # Calculate aggregate line
  aggregate_data_wave2 <- HSA_data_wave2 %>%
    group_by(collection_week) %>% 
    summarise(
      total_ICU_admissions = sum(ICU_admissions, na.rm = TRUE),
      total_bed_sum = sum(Bed_sum, na.rm = TRUE),
      .groups = "drop"
    ) %>% 
    mutate(ICU_occupancy = total_ICU_admissions/total_bed_sum) %>% 
    filter(!is.na(ICU_occupancy), ICU_occupancy != 0)
  
  pool_example_wave2 <- ggplot() + 
    # Plot all hospitals in light blue
    geom_line(data = processed_data_wave2, 
              aes(x = collection_week, y = ICU_occupancy*100, 
                  group = hospital_pk), 
              linewidth = 1, col = "lightblue", alpha = 0.5) +  
    # Plot the hospital pool in purple
    geom_line(data = aggregate_data_wave2, 
              aes(x = collection_week, y = ICU_occupancy*100), 
              linewidth = 1, col = "#634BFA") + 
    labs(x = "Date", 
         y = "Weekly ICU Occupancy\nby COVID patients (%)", 
         title = paste("HSA", HSA_example, ": Winter 2020")) +  
    theme_bw() +   
    ylim(0, 100) +
    theme(
      plot.title = element_text(size = 16, hjust = 0.5),
      strip.background = element_blank(),
      strip.text = element_text(size = 16),
      legend.position = "none",
      legend.text = element_text(size = 12),
      legend.title = element_text(size = 14),
      axis.text.x = element_text(size = rel(1.5)),
      axis.text.y = element_text(size = rel(1.5)),
      axis.title.x = element_text(size = 14),
      axis.title.y = element_text(size = 14),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank()
    )
  
  # ========================================
  # Delta Example
  # ========================================
  HSA_data_delta <- delta_data %>% 
    filter(HSA == HSA_example, hospital_pk %in% valid_hospitals_delta) %>%
    group_by(hospital_pk)
  
  processed_data_delta <- HSA_data_delta %>%
    group_by(hospital_pk) %>%
    mutate(
      ICU_occupancy = ICU_admissions/Bed_sum,
      .groups = "drop"
    ) %>% 
    filter(!is.na(ICU_occupancy))
  
  # Calculate aggregate line
  aggregate_data_delta <- HSA_data_delta %>%
    group_by(collection_week) %>% 
    summarise(
      total_ICU_admissions = sum(ICU_admissions, na.rm = TRUE),
      total_bed_sum = sum(Bed_sum, na.rm = TRUE),
      .groups = "drop"
    ) %>% 
    mutate(ICU_occupancy = total_ICU_admissions/total_bed_sum) %>% 
    filter(!is.na(ICU_occupancy), ICU_occupancy != 0)
  
  pool_example_delta <- ggplot() + 
    # Plot all hospitals in light blue
    geom_line(data = processed_data_delta, 
              aes(x = collection_week, y = ICU_occupancy*100, 
                  group = hospital_pk), 
              linewidth = 1, alpha = 0.5, col = "lightblue") +   
    # Plot the hospital pool in purple
    geom_line(data = aggregate_data_delta, 
              aes(x = collection_week, y = ICU_occupancy*100), 
              linewidth = 1, col = "#634BFA") +  
    labs(x = "Date", 
         y = "Weekly ICU Occupancy\nby COVID patients (%)", 
         title = paste("HSA", HSA_example, ": Delta")) +
    ylim(0, 100) +
    xlim(min(aggregate_data_delta$collection_week), max(aggregate_data_delta$collection_week)) +
    theme_bw() +    
    theme(
      plot.title = element_text(size = 16, hjust = 0.5),
      strip.background = element_blank(),
      strip.text = element_text(size = 16),
      legend.position = "none",
      legend.text = element_text(size = 12),
      legend.title = element_text(size = 14),
      axis.text.x = element_text(size = rel(1.5)),
      axis.text.y = element_text(size = rel(1.5)),
      axis.title.x = element_text(size = 14),
      axis.title.y = element_text(size = 14),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank()
    )
  
  # ========================================
  # Omicron Example (with legend)
  # ========================================
  HSA_data_omicron <- omicron_data %>% 
    filter(HSA == HSA_example, hospital_pk %in% valid_hospitals_omicron) %>%
    group_by(hospital_pk)
  
  processed_data_omicron <- HSA_data_omicron %>%
    group_by(hospital_pk) %>%
    mutate(
      ICU_occupancy = ICU_admissions/Bed_sum,
      .groups = "drop"
    ) %>% 
    filter(!is.na(ICU_occupancy))
  
  # Calculate aggregate line
  aggregate_data_omicron <- HSA_data_omicron %>%
    group_by(collection_week) %>% 
    summarise(
      total_ICU_admissions = sum(ICU_admissions, na.rm = TRUE),
      total_beds = sum(Bed_sum, na.rm = TRUE),
      .groups = "drop"
    ) %>% 
    mutate(ICU_occupancy = total_ICU_admissions/total_beds) %>% 
    filter(!is.na(ICU_occupancy), ICU_occupancy != 0)
  
  pool_example_omicron <- ggplot() + 
    # Plot all hospitals with a label for legend
    geom_line(data = processed_data_omicron, 
              aes(x = collection_week, y = ICU_occupancy*100, 
                  group = hospital_pk, color = "Individual Hospital"),  
              linewidth = 1, alpha = 0.5) +   
    # Plot the hospital pool with a label for legend
    geom_line(data = aggregate_data_omicron, 
              aes(x = collection_week, y = ICU_occupancy*100, 
                  color = "HSA-wide Pool"),  
              linewidth = 1) +  
    scale_color_manual(values = c("Individual Hospital" = "lightblue", 
                                  "HSA-wide Pool" = "#634BFA")) +
    labs(x = "Date", 
         y = "Weekly ICU Occupancy\nby COVID patients (%)", 
         title = paste("HSA", HSA_example, ": Omicron"), 
         color = "") +
    ylim(0, 100) +
    theme_bw() +    
    theme(
      plot.title = element_text(size = 16, hjust = 0.5),
      strip.background = element_blank(),
      strip.text = element_text(size = 16),
      legend.position = "right",
      legend.text = element_text(size = 12),
      legend.title = element_text(size = 14),
      axis.text.x = element_text(size = rel(1.5)),
      axis.text.y = element_text(size = rel(1.5)),
      axis.title.x = element_text(size = 14),
      axis.title.y = element_text(size = 14),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank()
    )
  
  return(list(
    wave2 = pool_example_wave2,
    delta = pool_example_delta,
    omicron = pool_example_omicron
  ))
}

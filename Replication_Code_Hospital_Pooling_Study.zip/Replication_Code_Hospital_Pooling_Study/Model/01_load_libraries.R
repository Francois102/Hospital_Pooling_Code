# Load all required libraries for the analysis
# If any library is not installed, install it first

required_packages <- c(
  # Data manipulation
  "dplyr",
  "tidyr",
  "rio",
  
  # Statistical modeling
  "nlme",
  "lme4",
  "qgam",
  "quantreg",
  "quantregGrowth",
  
  # Time series
  "TTR",
  "slider",
  "lubridate",
  
  # Visualization
  "ggplot2",
  "patchwork",
  "scales",
  "cowplot",
  "grid"
  
)

# Check and install missing packages
missing_packages <- required_packages[!(required_packages %in% installed.packages()[,"Package"])]
if(length(missing_packages) > 0) {
  print(paste("Installing missing packages:", paste(missing_packages, collapse=", ")))
  install.packages(missing_packages)
}

# Load all packages
invisible(lapply(required_packages, library, character.only = TRUE))

print("All libraries loaded successfully")
# Helper function to process facility data

#Prepares facility-level hospital data for the temporal clustering and health effects 
#analyses by calculating what proportion of each HSA's population each hospital serves

# Used by both temporal clustering and health effects analyses

process_facility_data <- function(All_Facilities, County, HSA_POP) {
  
  # Process dates and select columns
  All_Facilities <- All_Facilities %>% 
    mutate(collection_week = as.Date(collection_week, '%Y/%m/%d')) %>% 
    select(collection_week, hospital_pk, fips_code,
           staffed_icu_adult_patients_confirmed_covid_7_day_sum,
           total_adult_patients_hospitalized_confirmed_covid_7_day_sum,
           total_staffed_adult_icu_beds_7_day_sum,
           inpatient_beds_used_covid_7_day_sum,
           total_beds_7_day_sum,
           hospital_name) %>%  
    rename(ICU_admissions = staffed_icu_adult_patients_confirmed_covid_7_day_sum,
           Hosp_occupancy = total_adult_patients_hospitalized_confirmed_covid_7_day_sum,
           Hosp_beds = total_beds_7_day_sum,
           Bed_sum = total_staffed_adult_icu_beds_7_day_sum)
  
  # Handle censored data
  All_Facilities <- All_Facilities %>%
    group_by(hospital_pk) %>%
    arrange(collection_week, hospital_pk) %>% 
    mutate(
      censored = case_when(
        ICU_admissions > 0 ~ 0, 
        ICU_admissions < 0 ~ 1,
        TRUE ~ NA_real_),
      ICU_admissions = case_when(
        ICU_admissions >= 0 ~ ICU_admissions, 
        ICU_admissions < 0 ~ 2,
        TRUE ~ NA_real_),
      Hosp_beds = case_when(
        Hosp_beds > 0 ~ Hosp_beds, 
        Hosp_beds < 0 ~ 2,
        TRUE ~ NA_real_),
      Hosp_occupancy = case_when(
        Hosp_occupancy > 0 ~ Hosp_occupancy, 
        Hosp_occupancy < 0 ~ 2,
        TRUE ~ NA_real_),
      Bed_sum = case_when(
        Bed_sum > 0 ~ Bed_sum, 
        Bed_sum < 0 ~ 2,
        TRUE ~ NA_real_)
    ) %>% 
    ungroup()
  
  # Filter out hospitals with no ICU beds
  All_Facilities <- All_Facilities %>%
    filter(Bed_sum > 0)
  
  # Join with County data
  All_Facilities <- All_Facilities %>% 
    left_join(
      County %>% select(HSA, FIPS),
      by = c("fips_code" = "FIPS")
    )
  
  # Join with HSA_POP data
  All_Facilities <- All_Facilities %>% 
    left_join(
      HSA_POP %>% select(Population, facilities, HSA, Cumul_w2, Capw2),
      by = "HSA"
    )
  
  # Add median capacity per hospital
  All_Facilities <- All_Facilities %>% 
    group_by(hospital_pk) %>% 
    mutate(median_capacity = median(Bed_sum, na.rm = TRUE)) %>% 
    ungroup()
  
  # Calculate HSA-level occupancy
  HSA_Occupancy <- All_Facilities %>%
    group_by(HSA) %>%
    summarise(
      HSA_Total_Occupancy = sum(Hosp_occupancy, na.rm = TRUE),
      Population_HSA = first(Population),
      .groups = "drop"
    )
  
  # Calculate hospital-level occupancy
  Hospital_Occupancy <- All_Facilities %>%
    group_by(hospital_pk) %>%
    summarise(
      Total_Hosp_Occupancy = sum(Hosp_occupancy, na.rm = TRUE),
      HSA = first(HSA),
      .groups = "drop"
    )
  
  # Join back and calculate proportions
  All_Facilities <- All_Facilities %>%
    left_join(Hospital_Occupancy, by = c("hospital_pk", "HSA")) %>%
    left_join(HSA_Occupancy, by = "HSA") %>%
    mutate(
      Occupancy_Proportion = Total_Hosp_Occupancy / HSA_Total_Occupancy,
      Hospital_Population = Occupancy_Proportion * Population_HSA
    )
  
  return(All_Facilities)
}
# Generate all figures for the paper
# This script creates all visualizations from the processed data

# Load all necessary data
print("Loading processed data for figure generation...")
load("Results/regression_models.RData")
load("Results/volatility_data.RData")
load("Results/temporal_clustering_data.RData")
load("Results/health_effects_data.RData")
load("Intermediate_outputs/ICU_occ.txt")

# Source figure generation functions
source("Model/07a_figure_functions.R")

# ========================================
# FIGURE 1: Regression Results
# ========================================
print("Generating Figure 1: Regression results...")

fig1 <- generate_regression_figure(
  hierarchical_lme, wave2_model_weighted, 
  delta_model_weighted, omicron_model_weighted,
  HSA_overall, HSA_overall_std, xlim_max = 1000000
)

ggsave(file="Figures/Figure1_regression.png", plot=fig1$combined, 
       width=15, height=10, dpi=300)
ggsave(file="Figures/Figure1_regression.svg", plot=fig1$combined, 
       width=15, height=10)

# ========================================
# FIGURE 2: Volatility Analysis
# ========================================
print("Generating Figure 2: Volatility analysis...")

fig2 <- generate_volatility_figure(HSA_df_long, HSA_df_jump, ICU_occ)

ggsave(file="Figures/Figure2_volatility.png", plot=fig2, 
       width=16, height=18, dpi=300)
ggsave(file="Figures/Figure2_volatility.svg", plot=fig2, 
       width=16, height=18)

# ========================================
# FIGURE 3: Temporal Clustering
# ========================================
print("Generating Figure 3: Temporal clustering...")

fig3 <- generate_temporal_clustering_figure(
  total, predictions_long, indiv_total, 
  total_peak_density, wave_means, hsa_plots,xlim_max=1000000  
)

ggsave(file="Figures/Figure3_temporal_clustering.png", plot=fig3, 
       width=16, height=18, dpi=300)
ggsave(file="Figures/Figure3_temporal_clustering.svg", plot=fig3, 
       width=16, height=18)

# ========================================
# FIGURE 4: Health Effects Heatmap
# ========================================
print("Generating Figure 4: Health effects heatmap...")

fig4 <- generate_health_effects_heatmap(
  heatmap_data_wave2, heatmap_data_delta, heatmap_data_omicron,
  heatmap_data_10th_wave2, heatmap_data_10th_delta, heatmap_data_10th_omicron,
  median_min, median_max, quantile_min, quantile_max
)

ggsave(file="Figures/Figure4_health_effects.png", plot=fig4, 
       width=14, height=9, dpi=600)
ggsave(file="Figures/Figure4_health_effects.svg", plot=fig4, 
       width=14, height=9)

# ========================================
# SUPPLEMENTARY FIGURES
# ========================================
print("Generating supplementary figures...")

# Figure S1: Full regression with all population sizes
fig_s1 <- generate_regression_figure(
  hierarchical_lme, wave2_model_weighted, 
  delta_model_weighted, omicron_model_weighted,
  HSA_overall, HSA_overall_std,
  xlim_max = 10000000  # No limit to show all populations
)

ggsave(file="Figures/FigureS1_regression_full.png", plot=fig_s1$combined, 
       width=15, height=10, dpi=300)

# Figure S2: Sample counts for health effects
fig_s2 <- generate_sample_count_heatmap(
  heatmap_data_wave2, heatmap_data_delta, heatmap_data_omicron
)

ggsave(file="Figures/FigureS2_sample_counts.png", plot=fig_s2, 
       width=10, height=4, dpi=600)

#Emprical plots of maximum ICU Occupancy aganst population size
# Generate empirical funnel plots
empirical_funnel_plots <- generate_empirical_funnel(
  HSA_df = HSA_df,
  ICU_occ = ICU_occ,
  example_HSA = 155,  # Bay-Jackson, FL
  pop_min = 30000,
  pop_max = 3000000
)

# Save the full empirical funnel figure
ggsave(file="Figures/FigureS_empirical_funnel.svg", 
       plot=empirical_funnel_plots$full_figure, 
       width=15, height=10)

ggsave(file="Figures/FigureS_empirical_funnel.png", 
       plot=empirical_funnel_plots$full_figure, 
       width=15, height=10, dpi=300)

# ========================================
# SUMMARY
# ========================================
print("========================================")
print("Figure generation complete!")
print("All figures saved to /Figures directory")



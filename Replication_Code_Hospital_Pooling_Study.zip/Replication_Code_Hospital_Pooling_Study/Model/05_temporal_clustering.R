# Temporal Clustering Analysis

# Load required data
load("Intermediate_outputs/HSA_df.txt")

# Import county and facility data
County <- import("Data/Data_County.xlsx")
All_Facilities<-import("Data/Data_Facility_TS.csv")

# Process facility data (same as in health effects)
source("Model/05a_process_facilities.R")
All_Facilities <- process_facility_data(All_Facilities, County, HSA_df)

# Filter for large HSAs
All_Facilities_pooling <- All_Facilities %>% 
  filter(Population_HSA > 1*10^6)

# Create wave-specific datasets
wave2_data <- All_Facilities_pooling %>%
  filter(collection_week > as.Date("2020-10-15") & collection_week < as.Date("2021-03-01")) 

delta_data <- All_Facilities_pooling %>%
  filter(collection_week > as.Date("2021-07-01") & collection_week < as.Date("2021-11-01")) 

omicron_data <- All_Facilities_pooling %>%
  filter(collection_week > as.Date("2021-11-01") & collection_week < as.Date("2022-02-28"))

# Source analysis functions
source("Model/05b_clustering_functions.R")

# Analyze individual hospital benefits from pooling
print("Analyzing individual hospital benefits from HSA-wide pooling...")
indiv_delta <- HSA_vs_Hosp(delta_data, weeks=10, hosps=1)
indiv_omicron <- HSA_vs_Hosp(omicron_data, weeks=10, hosps=1)
indiv_wave2 <- HSA_vs_Hosp(wave2_data, weeks=10, hosps=1)

# Add wave labels
indiv_delta <- indiv_delta %>% mutate(wave="Delta")
indiv_omicron <- indiv_omicron %>% mutate(wave="Omicron")
indiv_wave2 <- indiv_wave2 %>% mutate(wave="Winter 2020")

# Combine results
indiv_total <- rbind(indiv_delta, indiv_omicron, indiv_wave2)
indiv_total$wave <- factor(indiv_total$wave, levels = c("Winter 2020", "Delta", "Omicron"))

# Count hospitals and HSAs included
count_summary <- indiv_total %>%
  group_by(wave) %>%
  summarise(
    n_unique_HSA = n_distinct(HSA),
    n_unique_hosp = n_distinct(pool)
  )
print("Number of HSAs and hospitals used in temporal clustering analysis")
print(count_summary)

# Analyze effect of hospital pool size on the CV
wave2_marginal <- Pooling_effect(wave2_data, weeks=10, hosps=1)
delta_marginal <- Pooling_effect(delta_data, weeks=10, hosps=1)
omicron_marginal <- Pooling_effect(omicron_data, weeks=10, hosps=1)

# Add wave labels
wave2_marginal <- wave2_marginal %>% mutate(wave="Winter 2020")
delta_marginal <- delta_marginal %>% mutate(wave="Delta")
omicron_marginal <- omicron_marginal %>% mutate(wave="Omicron")

# Calculate HSA-wide coefficients of variation
HSA_wide_wave2 <- HSA_wide_pooling(wave2_data, weeks=10)
HSA_wide_delta <- HSA_wide_pooling(delta_data, weeks=10)
HSA_wide_omicron <- HSA_wide_pooling(omicron_data, weeks=10)

# Join HSA-wide data with marginal effects
wave2_marginal <- wave2_marginal %>%
  left_join(HSA_wide_wave2 %>% select(HSA, coef_var_HSA), by = "HSA")

delta_marginal <- delta_marginal %>%
  left_join(HSA_wide_delta %>% select(HSA, coef_var_HSA), by = "HSA")

omicron_marginal <- omicron_marginal %>%
  left_join(HSA_wide_omicron %>% select(HSA, coef_var_HSA), by = "HSA")

# Save intermediate results
save(wave2_marginal, file="Intermediate_outputs//wave2_marginal.R")
save(delta_marginal, file="Intermediate_outputs//delta_marginal.R")
save(omicron_marginal, file="Intermediate_outputs//omicron_marginal.R")

# Combine all marginal effects
total <- rbind(delta_marginal, omicron_marginal, wave2_marginal)
total$wave <- factor(total$wave, levels = c("Winter 2020", "Delta", "Omicron"))
total <- total %>% mutate(diff_coef = coef_var - coef_var_HSA)

# Fit quantile regression models
quantile_models <- total %>%
  group_by(wave) %>%
  group_split() %>%
  lapply(function(df) {
    list(
      q10 = gcrq(diff_coef ~ ps(Population), tau = 0.1, data = df),
      q50 = gcrq(diff_coef ~ ps(Population), tau = 0.5, data = df),
      q90 = gcrq(diff_coef ~ ps(Population), tau = 0.9, data = df),
      wave = unique(df$wave)
    )
  })

# Generate predictions
predictions <- quantile_models %>%
  lapply(function(models) {
    data.frame(
      Population = seq(min(total$Population), max(total$Population), length.out = 100)
    ) %>%
      mutate(
        wave = models$wave,
        q10 = predict(models$q10, newdata = data.frame(Population = Population)),
        q50 = predict(models$q50, newdata = data.frame(Population = Population)),
        q90 = predict(models$q90, newdata = data.frame(Population = Population))
      )
  }) %>%
  bind_rows()

# Transform predictions to long format
predictions_long <- predictions %>%
  pivot_longer(
    cols = starts_with("q"),
    names_to = "quantile",
    values_to = "value"
  ) %>% 
  mutate(
    quantile = recode(quantile, q10 = "0.1", q50 = "0.5", q90 = "0.9")
  )

# Analyze peak timing differences
print("Analyzing peak timing differences between hospitals...")
# Use full dataset for peak timing (not just large HSAs)
wave2_data_peaks <- All_Facilities %>%
  filter(collection_week > as.Date("2020-10-15") & collection_week < as.Date("2021-03-01"))

delta_data_peaks <- All_Facilities %>%
  filter(collection_week > as.Date("2021-07-01") & collection_week < as.Date("2021-11-01"))

omicron_data_peaks <- All_Facilities %>%
  filter(collection_week > as.Date("2021-11-01") & collection_week < as.Date("2022-02-28"))

# Calculate timing differences
peak_diff_wave2 <- calculate_timing_difference(wave2_data_peaks)
peak_diff_wave2 <- peak_diff_wave2 %>% mutate(wave="Winter 2020")

peak_diff_delta <- calculate_timing_difference(delta_data_peaks)
peak_diff_delta <- peak_diff_delta %>% mutate(wave="Delta")

peak_diff_omicron <- calculate_timing_difference(omicron_data_peaks)
peak_diff_omicron <- peak_diff_omicron %>% mutate(wave="Omicron")

# Combine peak timing data
total_peak_density <- rbind(peak_diff_wave2, peak_diff_delta, peak_diff_omicron)
total_peak <- rbind(peak_diff_wave2, peak_diff_delta, peak_diff_omicron)

total_peak$timing_difference <- factor(total_peak$timing_difference, levels = as.character(0:14))
total_peak$wave <- factor(total_peak$wave, levels = c("Winter 2020", "Delta", "Omicron"))

# Calculate relative frequencies
relative_peak <- total_peak %>%
  group_by(wave, timing_difference) %>%
  summarise(count = n(), .groups = "drop") %>%
  group_by(wave) %>%
  mutate(relative_frequency = count / sum(count))

# Calculate mean timing differences
wave_means <- total_peak_density %>%
  group_by(wave) %>%
  summarise(mean_timing = mean(timing_difference))

total_peak_density$wave <- factor(total_peak_density$wave, levels = c("Winter 2020", "Delta", "Omicron"))

# Generate HSA example plots

source("Model/05c_hsa_example_plots.R")

hsa_plots <- create_hsa_example_plots(wave2_data, delta_data, omicron_data, HSA_example = 61)


# Save all results
save(indiv_total, total, predictions_long, total_peak_density, 
     wave_means, relative_peak, wave2_marginal, delta_marginal, 
     omicron_marginal, wave2_data, delta_data, omicron_data,hsa_plots,
     file = "Results/temporal_clustering_data.RData")

print("Temporal clustering analysis complete. Data saved to Results/temporal_clustering_data.RData")

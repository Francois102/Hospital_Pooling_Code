# Helper functions for wave-specific calculations

#safe_max ensures max does not output inf
safe_max <- function(x) {
  if (is.null(x) || length(x) == 0 || all(is.na(x))) {
    return(NA_real_)
  } else {
    return(max(x, na.rm = TRUE))
  }
}


calculate_wave_metrics <- function(HSA_numb, HSA_name,ICU_occ, ICU_demand, 
                                   Capacity,Hosp_demand,HSA_df) {
  
  # Define wave periods
  waves <- list(
    Delta = list(
      start = as.Date("07/01/2021", '%m/%d/%Y'),
      end = as.Date("11/01/2021", '%m/%d/%Y'),
      suffix = "Delta"
    ),
    Omicron = list(
      start = as.Date("11/01/2021", '%m/%d/%Y'),
      end = as.Date("02/28/2022", '%m/%d/%Y'),
      suffix = "Omicron"
    ),
    Wave2 = list(
      start = as.Date("10/15/2020", '%m/%d/%Y'),
      end = as.Date("03/01/2021", '%m/%d/%Y'),
      suffix = "w2"
    )
  )
  
  # Process each wave
  for(wave_name in names(waves)) {
    wave <- waves[[wave_name]]
    
    # Calculate maximum estimated ICU occupancy
    max_occ <-ICU_occ %>%
      filter(Date > wave$start, Date < wave$end) %>%
      pull(!!sym(HSA_name)) %>%
      safe_max()*100
    
    HSA_df[[paste0("max_occ_", wave$suffix)]][HSA_df$HSA == HSA_numb] <- max_occ
    
    # Find peak date
    peak_date <- ICU_occ %>%
      filter(Date > wave$start, Date < wave$end) %>%
      filter(!!sym(HSA_name) ==  safe_max(!!sym(HSA_name))) %>%
      pull(Date)
    
    if(length(peak_date) > 0) {
      HSA_df[[paste0("Peak_", wave$suffix)]][HSA_df$HSA == HSA_numb] <- peak_date[1]
      
      # Calculate capacity at peak (weekly cumulative capacity)
      cap_at_peak <- Capacity %>%
        filter(Date == peak_date[1]) %>%
        pull(!!sym(HSA_name))
      
      #Calculate weekly average capacity per 100,000 population
      cap_normalized <- cap_at_peak / (7 * HSA_df$Population[HSA_df$HSA == HSA_numb]) * 10^5
      HSA_df[[paste0("Cap", wave$suffix)]][HSA_df$HSA == HSA_numb] <- cap_normalized
      
    }
    
    
    # Calculate cumulative hospitalizations
    cumul <- Hosp_demand %>%
      filter(Date > wave$start, Date < wave$end) %>%
      pull(!!sym(HSA_name)) %>%
      sum(na.rm = TRUE)
    
    HSA_df[[paste0("Cumul_", wave$suffix)]][HSA_df$HSA == HSA_numb] <- cumul
    
    
    # Calculate 4-week cumulative around peak
    if(!is.na(peak_date[1])) {
      cumul_4w <- Hosp_demand %>%
        filter(Date >= (peak_date[1] - weeks(3)) & Date <= peak_date[1]) %>%
        pull(!!sym(HSA_name)) %>%
        sum(na.rm = TRUE)
      
      HSA_df[[paste0("Cumul_", wave$suffix, "_4w")]][HSA_df$HSA == HSA_numb] <- cumul_4w
    }
    
    # Calculate volatility (standard deviation)
    icu_data <- ICU_occ %>%
      filter(Date > wave$start, Date < wave$end) %>%
      pull(!!sym(HSA_name))
    
    if(length(icu_data) > 0) {
      ma_data <- slide_mean(icu_data, before = 1, after = 1)
      diff_data <- icu_data - ma_data
      HSA_df[[paste0("stdv_ICU_", wave$suffix)]][HSA_df$HSA == HSA_numb] <- sd(diff_data, na.rm = TRUE)
      
      # Calculate maximum jump
      jump <-  safe_max(diff(icu_data, lag = 1))
      jump_col <- ifelse(wave$suffix == "w2", "jump_wave2", paste0("jump_", tolower(wave$suffix)))
      HSA_df[[jump_col]][HSA_df$HSA == HSA_numb] <- jump
    }
  }
  
  # Update the parent environment's HSA_df
  assign("HSA_df", HSA_df, envir = parent.frame())
}

# Function to calculate vaccination rates at peak times
calculate_vaccination_at_peaks <- function(County, HSA_df, Vaccination) {
  
  # Calculate average vaccination during Delta period
  Delta_period_vaccination <- Vaccination %>% 
    filter(Date < as.Date("11/01/2021", '%m/%d/%Y'), 
           Date > as.Date("07/01/2021", '%m/%d/%Y')) %>%
    group_by(FIPS) %>%
    summarise(Avg_Vaccination_Delta_Period = mean(Administered_Dose1_Pop_Pct, na.rm = TRUE),
              .groups = 'drop')
  
  # Initialize columns if they don't exist
  if(!"Vaccination_Delta" %in% names(County)) {
    County$Vaccination_Delta <- NA
    County$Vaccination_Omicron <- NA
    County$Avg_Vaccination_Delta_Period <- NA
  }
  
  # Process each county
  for (i in 1:dim(County)[1]) {
    Peak_Delta <- HSA_df$Peak_Delta[HSA_df$HSA == County$HSA[i]]
    Peak_Omicron <- HSA_df$Peak_Omicron[HSA_df$HSA == County$HSA[i]]
    
    if(!is.na(Peak_Delta)) {
      # Get vaccination at Delta peak
      Vaccination_Delta <- Vaccination %>% 
        filter(abs(as.numeric(Date) - as.numeric(Peak_Delta)) == 
                 min(abs(as.numeric(Date) - as.numeric(Peak_Delta))),
               FIPS == County$FIPS[i])
      
      if(nrow(Vaccination_Delta) != 0) {
        County$Vaccination_Delta[i] <- as.numeric(Vaccination_Delta$Administered_Dose1_Pop_Pct)  
      }
    }
    
    if(!is.na(Peak_Omicron)) {
      # Get vaccination at Omicron peak
      Vaccination_Omicron <- Vaccination %>% 
        filter(abs(as.numeric(Date) - as.numeric(Peak_Omicron)) == 
                 min(abs(as.numeric(Date) - as.numeric(Peak_Omicron))),
               FIPS == County$FIPS[i])
      
      if(nrow(Vaccination_Omicron) != 0) {
        County$Vaccination_Omicron[i] <- as.numeric(Vaccination_Omicron$Administered_Dose1_Pop_Pct) 
      }
    }
    
    # Get average vaccination during Delta period
    avg_vax <- Delta_period_vaccination$Avg_Vaccination_Delta_Period[
      Delta_period_vaccination$FIPS == County$FIPS[i]]
    
    if(length(avg_vax) > 0) {
      County$Avg_Vaccination_Delta_Period[i] <- avg_vax
    }
  }
  
  return(County)
}

# Function to aggregate vaccination to HSA level
aggregate_vaccination_to_HSA <- function(County, HSA_df) {
  
  for(o in 1:dim(HSA_df)[1]) {
    Filter <- County %>% 
      filter(HSA == HSA_df[o,1]) %>% 
      select(Vaccination_Delta, Vaccination_Omicron, Population, Avg_Vaccination_Delta_Period)
    
    Population_HSA <- sum(Filter$Population)
    
    if(Population_HSA > 0) {
      # Calculate population-weighted average vaccination rates
      HSA_df$Vaccination_Delta[o] <- round(
        sum((Filter$Population * Filter$Vaccination_Delta), na.rm = TRUE) / Population_HSA, 
        digits = 1)
      
      HSA_df$Vaccination_Omicron[o] <- round(
        sum((Filter$Population * Filter$Vaccination_Omicron), na.rm = TRUE) / Population_HSA, 
        digits = 1)
      
      HSA_df$Avg_Vaccination_Delta_Period[o] <- round(
        sum((Filter$Population * Filter$Avg_Vaccination_Delta_Period), na.rm = TRUE) / Population_HSA, 
        digits = 1)
    }
  }
  
  return(HSA_df)
}

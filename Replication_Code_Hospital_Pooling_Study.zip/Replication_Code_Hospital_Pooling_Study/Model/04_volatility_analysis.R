# Volatility Analysis

# Load required data
load("Intermediate_outputs/HSA_df.txt")
load("Intermediate_outputs/ICU_occ.txt")

# Filter HSAs
HSA_df_filtered <- HSA_df %>% 
  filter(Population > 30000) %>%
  filter(max_occ_Delta > 0, max_occ_Omicron > 0, max_occ_w2 > 0)

# Calculate power law relationships for volatility
print("Calculating power law relationships...")

# Function to fit power law model
fit_power_law <- function(data, volatility_col, wave_name) {
  # Create a filtered dataset first
  filtered_data <- data %>% 
    filter(Population > 30000)
  
  # Filter for non-zero values in the volatility column
  filtered_data <- filtered_data[filtered_data[[volatility_col]] > 0, ]
  
  # Fit the model
  model <- lm(as.formula(paste("log(", volatility_col, ") ~ log(Population)")), 
              data = filtered_data)
  
  cat(paste("\n", wave_name, "Power Law Model:\n"))
  print(summary(model))
  
  return(model)
}

# Fit models for each wave
model_w2 <- fit_power_law(HSA_df_filtered, "stdv_ICU_w2", "Winter 2020")
model_delta <- fit_power_law(HSA_df_filtered, "stdv_ICU_Delta", "Delta")
model_omicron <- fit_power_law(HSA_df_filtered, "stdv_ICU_Omicron", "Omicron")

# Transform data to long format for plotting
HSA_df_long <- HSA_df_filtered %>%
  pivot_longer(
    cols = c(stdv_ICU_w2, stdv_ICU_Delta, stdv_ICU_Omicron),
    names_to = "wave", 
    values_to = "volatility"
  ) %>%
  mutate(
    volatility = volatility * 100,  # Convert to percentage
    wave = case_when(
      wave == "stdv_ICU_w2" ~ "Winter 2020",
      wave == "stdv_ICU_Delta" ~ "Delta",
      wave == "stdv_ICU_Omicron" ~ "Omicron"
    ),
    wave = factor(wave, levels = c("Winter 2020", "Delta", "Omicron"))
  )

# Add power law equations for plotting
HSA_df_long <- HSA_df_long %>%
  mutate(
    equation = case_when(
      wave == "Delta" ~ "Volatility == 32 %*% Population^-0.58",
      wave == "Omicron" ~ "Volatility == 12 %*% Population^-0.49",
      wave == "Winter 2020" ~ "Volatility == 12 %*% Population^-0.50",
      TRUE ~ NA_character_
    )
  )

# Process jump data
HSA_df_jump <- HSA_df_filtered %>%
  pivot_longer(
    cols = c(jump_wave2, jump_delta, jump_omicron),
    names_to = "wave", 
    values_to = "Jump"
  ) %>%
  mutate(
    wave = case_when(
      wave == "jump_wave2" ~ "Winter 2020",
      wave == "jump_delta" ~ "Delta",
      wave == "jump_omicron" ~ "Omicron"
    ),
    wave = factor(wave, levels = c("Winter 2020", "Delta", "Omicron"))
  )

# Save processed data for plotting
save(HSA_df_long, HSA_df_jump, model_w2, model_delta, model_omicron,
     file = "Results/volatility_data.RData")

print("Volatility analysis complete. Data saved to Results/volatility_data.RData")

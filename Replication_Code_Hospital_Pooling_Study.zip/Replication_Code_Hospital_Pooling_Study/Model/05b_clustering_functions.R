# Functions for temporal clustering analysis

#Variable "weeks" represents the minimum number of weekly observations required 
#for a hospital to be included in the analysis

#Variable "hosps" represents the minimum number of facilities with ICU occupancy required 
#for a Helath Service Area to be included in the analysis

# Helper function to generate random combinations
generate_random_combinations <- function(elements, k, n_samples) {
  unique_combinations <- list()
  
  while (length(unique_combinations) < n_samples) {
    new_combination <- sort(sample(elements, k, replace = FALSE))
    
    if (!any(sapply(unique_combinations, function(x) all(x == new_combination)))) {
      unique_combinations[[length(unique_combinations) + 1]] <- new_combination
    }
  }
  
  unique_combinations
}

# Function that takes each individual hospital and compares its coefficient of variation (CV) 
#to the CV of the entire HSA
HSA_vs_Hosp <- function(data, weeks, hosps) {
  results_list <- list()
  result_index <- 1
  
  unique_HSAs <- unique(data$HSA)
  
  # Smooth the data
  data <- data %>%
    arrange(hospital_pk, collection_week) %>%
    group_by(hospital_pk) %>%
    mutate(
      Bed_sum = slide_mean(Bed_sum, before = 1, after = 1, complete = TRUE, na_rm = TRUE),
      ICU_admissions = slide_mean(ICU_admissions, before = 1, after = 1, complete = TRUE, na_rm = TRUE)
    ) %>%
    ungroup()
  
  # Identify valid hospitals
  valid_hospitals_all <- data %>%
    group_by(hospital_pk) %>%
    summarise(
      total_ICU_admissions = sum(ICU_admissions, na.rm = TRUE),
      weeks_with_positive_ICU_admissions = sum(ICU_admissions > 0, na.rm = TRUE),
      HSA = first(HSA),
      .groups = "drop"
    ) %>% 
    filter(total_ICU_admissions > 0, weeks_with_positive_ICU_admissions > weeks) %>% 
    select(HSA, hospital_pk)
  
  # Process each HSA
  for (i in 1:length(unique_HSAs)) {
    HSA_data <- data %>%
      filter(HSA == unique_HSAs[i])
    
    valid_hospitals <- valid_hospitals_all %>%
      filter(HSA == unique_HSAs[i]) %>% 
      pull(hospital_pk)
    
    if (length(valid_hospitals) > hosps) {
      
      for (pool in valid_hospitals) {
        
        # Calculate pool coefficient of variation
        Pool <- HSA_data %>% 
          filter(hospital_pk %in% pool) %>% 
          group_by(collection_week) %>% 
          summarise(
            total_ICU_admissions = sum(ICU_admissions, na.rm = TRUE),
            .groups = "drop"
          ) %>%
          summarise(coef_var = sd(total_ICU_admissions, na.rm = TRUE) / 
                      mean(total_ICU_admissions, na.rm = TRUE))
        
        # Calculate HSA-wide coefficient of variation
        HSA <- HSA_data %>% 
          group_by(collection_week) %>% 
          summarise(
            total_ICU_admissions = sum(ICU_admissions, na.rm = TRUE),
            .groups = "drop"
          ) %>%
          summarise(coef_var = sd(total_ICU_admissions, na.rm = TRUE) / 
                      mean(total_ICU_admissions, na.rm = TRUE))
        
        results_list[[result_index]] <- data.frame(
          pool = paste(pool, collapse = ", "),
          coef_var = Pool$coef_var,
          coef_var_HSA = HSA$coef_var,
          diff_coef = Pool$coef_var - HSA$coef_var,
          HSA = unique_HSAs[i]
        )
        result_index <- result_index + 1
      }
    }
  }
  
  results <- bind_rows(results_list)
  return(results)
}

# Function that creates hospital pools within HSAs of varying sizes (1, 2, 3... up to 10 hospitals) 
#and calculates CV for each pool size
Pooling_effect <- function(data, weeks, hosps) {
  results_list <- list()
  result_index <- 1
  
  unique_HSAs <- unique(data$HSA)
  
  # Smooth the data
  data <- data %>%
    arrange(hospital_pk, collection_week) %>%
    group_by(hospital_pk) %>%
    mutate(
      Bed_sum = slide_mean(Bed_sum, before = 1, after = 1, complete = TRUE, na_rm = TRUE),
      ICU_admissions = slide_mean(ICU_admissions, before = 1, after = 1, complete = TRUE, na_rm = TRUE)
    ) %>%
    ungroup()
  
  # Identify valid hospitals
  valid_hospitals_all <- data %>%
    group_by(hospital_pk) %>%
    summarise(
      total_ICU_admissions = sum(ICU_admissions, na.rm = TRUE),
      weeks_with_positive_ICU_admissions = sum(ICU_admissions > 0, na.rm = TRUE),
      HSA = first(HSA),
      .groups = "drop"
    ) %>% 
    filter(total_ICU_admissions > 0, weeks_with_positive_ICU_admissions > weeks) %>% 
    select(HSA, hospital_pk)
  
  # Process each HSA
  for (i in 1:length(unique_HSAs)) {
    HSA_data <- data %>%
      filter(HSA == unique_HSAs[i])
    
    valid_hospitals <- valid_hospitals_all %>%
      filter(HSA == unique_HSAs[i]) %>% 
      pull(hospital_pk)
    
    if (length(valid_hospitals) > hosps) {
      
      iterations <- ifelse(length(valid_hospitals) < 11, length(valid_hospitals), 10)
      
      for (pool_size in 1:iterations) {
        
        # Generate combinations
        if (choose(length(valid_hospitals), pool_size) > 100) {
          hospital_combinations <- generate_random_combinations(valid_hospitals, pool_size, 100)
        } else {
          hospital_combinations <- combn(valid_hospitals, pool_size, simplify = FALSE)
        }
        
        for (pool in hospital_combinations) {
          
          # Calculate pool statistics
          Pool <- HSA_data %>% 
            filter(hospital_pk %in% pool) %>% 
            group_by(collection_week) %>% 
            summarise(
              total_ICU_admissions = sum(ICU_admissions, na.rm = TRUE),
              .groups = "drop"
            ) %>%
            summarise(coef_var = sd(total_ICU_admissions, na.rm = TRUE) / 
                        mean(total_ICU_admissions, na.rm = TRUE))
          
          # Calculate population for pool
          Hospital_Population <- HSA_data %>%
            filter(hospital_pk %in% pool) %>% 
            group_by(hospital_pk) %>%
            slice(1) %>%
            ungroup() %>%
            pull(Hospital_Population) %>%
            sum(na.rm = TRUE)
          
          results_list[[result_index]] <- data.frame(
            HSA = unique_HSAs[i],
            pool = paste(pool, collapse = ", "),
            pool_size = pool_size,
            coef_var = Pool$coef_var,
            total_hospitals = length(valid_hospitals),
            Population = Hospital_Population,
            Capacity = HSA_data$Capw2[1]
          )
          result_index <- result_index + 1
        }
      }
    }
  }
  
  results <- bind_rows(results_list)
  return(results)
}

# Function that calculates the CV for the entire HSA
HSA_wide_pooling <- function(data, weeks) {
  results_list <- list()
  result_index <- 1
  
  unique_HSAs <- unique(data$HSA)
  
  # Smooth the data
  data <- data %>%
    arrange(hospital_pk, collection_week) %>%
    group_by(hospital_pk) %>%
    mutate(
      Bed_sum = slide_mean(Bed_sum, before = 1, after = 1, complete = TRUE, na_rm = TRUE),
      ICU_admissions = slide_mean(ICU_admissions, before = 1, after = 1, complete = TRUE, na_rm = TRUE)
    ) %>%
    ungroup()
  
  # Process each HSA
  for (i in 1:length(unique_HSAs)) {
    HSA_data <- data %>%
      filter(HSA == unique_HSAs[i])
    
    Pool <- HSA_data %>% 
      group_by(collection_week) %>% 
      summarise(
        total_ICU_admissions = sum(ICU_admissions, na.rm = TRUE),
        .groups = "drop"
      ) %>%
      summarise(coef_var = sd(total_ICU_admissions, na.rm = TRUE) / 
                  mean(total_ICU_admissions, na.rm = TRUE))
    
    results_list[[result_index]] <- data.frame(
      HSA = unique_HSAs[i],
      coef_var_HSA = Pool$coef_var
    )
    result_index <- result_index + 1
  }
  
  results <- bind_rows(results_list)
  return(results)
}

# Function to calculate timing differences between hospital peaks
calculate_timing_difference <- function(data) {
  results <- data.frame()
  unique_HSAs <- unique(data$HSA)
  
  for (i in seq_along(unique_HSAs)) {
    HSA_data <- data %>%
      filter(HSA == unique_HSAs[i]) %>%
      arrange(hospital_pk, collection_week) %>%
      group_by(hospital_pk) %>%
      mutate(
        ICU_admissions = slide_mean(ICU_admissions, before = 1, after = 1, 
                                    complete = TRUE, na_rm = TRUE)
      ) %>%
      ungroup()
    
    # Find valid hospitals
    valid_hospitals <- HSA_data %>%
      group_by(hospital_pk) %>%
      summarise(
        total_ICU_admissions = sum(ICU_admissions, na.rm = TRUE),
        .groups = "drop"
      ) %>%
      filter(total_ICU_admissions > 0) %>%
      pull(hospital_pk)
    
    if (length(valid_hospitals) < 6) next
    
    # Sample 6 hospitals
    sampled_hospitals <- sample(valid_hospitals, 6)
    
    # Get timing of maximum ICU occupancy
    hospital_max_timing <- HSA_data %>%
      filter(hospital_pk %in% sampled_hospitals) %>%
      group_by(hospital_pk) %>%
      summarise(
        max_week = collection_week[which.max(ICU_admissions)],
        .groups = "drop"
      )
    
    # Calculate pairwise differences
    timing_differences <- combn(1:nrow(hospital_max_timing), 2, function(index_pair) {
      hosp_1 <- hospital_max_timing[index_pair[1], ]
      hosp_2 <- hospital_max_timing[index_pair[2], ]
      
      diff <- round(as.numeric(abs(as.numeric(hosp_1$max_week) - 
                                     as.numeric(hosp_2$max_week))) / 7)
      
      return(data.frame(
        HSA = unique_HSAs[i],
        hospital_1 = hosp_1$hospital_pk,
        hospital_2 = hosp_2$hospital_pk,
        timing_difference = diff
      ))
    }, simplify = FALSE)
    
    HSA_results <- do.call(rbind, timing_differences)
    results <- rbind(results, HSA_results)
  }
  
  return(results)
}
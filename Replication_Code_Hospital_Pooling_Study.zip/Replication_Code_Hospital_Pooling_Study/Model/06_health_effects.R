# Health Effects Analysis
# Load required data
load("Intermediate_outputs/HSA_df.txt")

# Import and process facility data
County <- import("Data/Data_County.xlsx")
All_Facilities<-import("Data/Data_Facility_TS.csv")

# Process facility data (uses same function as temporal clustering)
source("Model/05a_process_facilities.R")
All_Facilities <- process_facility_data(All_Facilities, County, HSA_df)

# Create wave-specific datasets
wave2_data <- All_Facilities %>%
  filter(collection_week > as.Date("2020-10-15") & collection_week < as.Date("2021-03-01"))

delta_data <- All_Facilities %>%
  filter(collection_week > as.Date("2021-07-01") & collection_week < as.Date("2021-11-01"))

omicron_data <- All_Facilities %>%
  filter(collection_week > as.Date("2021-11-01") & collection_week < as.Date("2022-02-28"))

# Define risk ratios from Bravata et al. 2021
Risk_ratios <- c(1, 1.22, 1.26, 1.81, 2.34)

# Source health effect calculation function
source("Model/06a_health_effect_function.R")

# Calculate health effects for each wave
print("Calculating health effects of pooling for Winter 2020...")
wave2_health_effect <- Pooling_health_effect(wave2_data, Risk_ratios)

print("Calculating health effects of pooling for Delta...")
delta_health_effect <- Pooling_health_effect(delta_data, Risk_ratios)

print("Calculating health effects of pooling for Omicron...")
omicron_health_effect <- Pooling_health_effect(omicron_data, Risk_ratios)

# Count HSAs and facilities included
count_winter2020 <- count_HSAs_and_facilities(wave2_data)
count_delta <- count_HSAs_and_facilities(delta_data)
count_omicron <- count_HSAs_and_facilities(omicron_data)

print("Count summary:")
print(paste("Winter 2020:", count_winter2020$n_HSAs, "HSAs,", 
            count_winter2020$n_facilities, "facilities"))
print(paste("Delta:", count_delta$n_HSAs, "HSAs,", 
            count_delta$n_facilities, "facilities"))
print(paste("Omicron:", count_omicron$n_HSAs, "HSAs,", 
            count_omicron$n_facilities, "facilities"))

# Process data for heatmap visualization
common_breaks <- c(10, 50, 75, 100, 200, 400)

process_data <- function(df) {
  df %>%
    mutate(
      Mean_Pop_th = Mean_Pop / 1000,
      Population_bin = cut(Mean_Pop_th, breaks = common_breaks)
    )
}

# Process each dataset
wave2_health_effect <- process_data(wave2_health_effect)
delta_health_effect <- process_data(delta_health_effect)
omicron_health_effect <- process_data(omicron_health_effect)

# Summarize median mortality change per group
summarize_median <- function(df) {
  df %>%
    filter(!is.na(Population_bin)) %>%
    group_by(pool_size, Population_bin) %>%
    summarise(
      Mortality_change_median = median(Mortality_change, na.rm = TRUE),
      count_per_group = n(),
      .groups = "drop"
    )
}

# Summarize 10th quantile of mortality change per group
summarize_qu10 <- function(df) {
  df %>%
    filter(!is.na(Population_bin)) %>%
    group_by(pool_size, Population_bin) %>%
    summarise(
      Mortality_change_qu10 = quantile(Mortality_change, probs = 0.1, na.rm = TRUE),
      count_per_group = n(),
      .groups = "drop"
    )
}

# Create summaries for heatmaps
heatmap_data_wave2 <- summarize_median(wave2_health_effect)
heatmap_data_delta <- summarize_median(delta_health_effect)
heatmap_data_omicron <- summarize_median(omicron_health_effect)

heatmap_data_10th_wave2 <- summarize_qu10(wave2_health_effect)
heatmap_data_10th_delta <- summarize_qu10(delta_health_effect)
heatmap_data_10th_omicron <- summarize_qu10(omicron_health_effect)

# Calculate color scale limits
all_median_values <- c(
  heatmap_data_wave2$Mortality_change_median,
  heatmap_data_delta$Mortality_change_median,
  heatmap_data_omicron$Mortality_change_median
)

all_10th_values <- c(
  heatmap_data_10th_wave2$Mortality_change_qu10,
  heatmap_data_10th_delta$Mortality_change_qu10,
  heatmap_data_10th_omicron$Mortality_change_qu10
)

median_min <- min(all_median_values, na.rm = TRUE)
median_max <- max(all_median_values, na.rm = TRUE)
quantile_min <- min(all_10th_values, na.rm = TRUE)
quantile_max <- max(all_10th_values, na.rm = TRUE)

# Save processed data
save(wave2_health_effect, delta_health_effect, omicron_health_effect,
     file = "Intermediate_outputs/wave2_health_effect.R")
save(delta_health_effect, file = "Intermediate_outputs/delta_health_effect.R")
save(omicron_health_effect, file = "Intermediate_outputs/omicron_health_effect.R")

save(heatmap_data_wave2, heatmap_data_delta, heatmap_data_omicron,
     heatmap_data_10th_wave2, heatmap_data_10th_delta, heatmap_data_10th_omicron,
     median_min, median_max, quantile_min, quantile_max,
     file = "Results/health_effects_data.RData")

print("Health effects analysis complete. Data saved to Results/health_effects_data.RData")

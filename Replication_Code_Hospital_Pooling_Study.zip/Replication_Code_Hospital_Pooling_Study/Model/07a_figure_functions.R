# Functions for generating figures
# This file contains all the plotting functions

# Function to generate regression figure (Figure 1)
generate_regression_figure <- function(hierarchical_lme, wave2_model, delta_model, 
                                       omicron_model, HSA_overall, HSA_overall_std,
                                       xlim_max = 1000000) {
  
  # Generate prediction data
  pop_values <- seq(min(HSA_overall$Population), max(HSA_overall$Population), length.out = 10000)
  inv_sqrt_pop_std <- (1/sqrt(pop_values) - mean(HSA_overall$inv_sqrt_pop, na.rm = TRUE)) / 
    sd(HSA_overall$inv_sqrt_pop, na.rm = TRUE)
  
  Cap_low <- round((10 - mean(HSA_overall$Capacity, na.rm = TRUE)) / 
                     sd(HSA_overall$Capacity, na.rm = TRUE), digits = 3)
  Cap_high <- round((35 - mean(HSA_overall$Capacity, na.rm = TRUE)) / 
                      sd(HSA_overall$Capacity, na.rm = TRUE), digits = 3)
  
  # Create prediction dataframes
  new_data <- data.frame(
    Population = pop_values,
    inv_sqrt_pop_std = inv_sqrt_pop_std,
    Capacity_std = rep(c(Cap_low, Cap_high), length(pop_values) / 2),
    Cumul_std = 0,
    vaccination_std = 0,
    is_Delta = 0,
    is_Omicron = 1,
    Over60_std = 0,
    Income_std = 0
  )
  
  # Generate predictions
  predicted_mean <- predict(hierarchical_lme, newdata = new_data, level = 0)
  
  # Get variance power function
  fitted_power <- summary(hierarchical_lme)$modelStruct$varStruct
  residual_sd <- hierarchical_lme$sigma * new_data$Population^fitted_power[[1]]
  
  # Prepare plot data
  plot_data <- new_data %>% 
    mutate(sd = residual_sd, predicted_mean = predicted_mean)
  
  plot_data$lower <- plot_data$predicted_mean - 1.96 * plot_data$sd
  plot_data$upper <- plot_data$predicted_mean + 1.96 * plot_data$sd
  
  # Generate predictions for individual waves
  wave2_predicted <- predict(wave2_model, newdata = new_data, level = 0)
  delta_predicted <- predict(delta_model, newdata = new_data, level = 0)
  omicron_predicted <- predict(omicron_model, newdata = new_data, level = 0)
  all_predicted <- predict(hierarchical_lme, newdata = new_data, level = 0)
  
  plot_data2 <- plot_data %>%
    mutate(
      wave2_predicted = wave2_predicted,
      delta_predicted = delta_predicted,
      omicron_predicted = omicron_predicted,
      all_predicted = all_predicted
    )
  
  # Create plots
  Low <- ggplot(plot_data2 %>% filter(Capacity_std == Cap_low,Population<xlim_max), aes(x = Population / 1000)) + 
    geom_line(aes(y = wave2_predicted, col = "Winter 2020"), size = 1.5) +
    geom_line(aes(y = delta_predicted, col = "Delta"), size = 1.5) + 
    geom_line(aes(y = omicron_predicted, col = "Omicron"), size = 1.5) + 
    geom_line(aes(y = all_predicted, col = "All Waves"), linetype = "dashed", size = 2) + 
    geom_ribbon(data = plot_data %>% filter(Capacity_std == Cap_low,Population<xlim_max), 
                aes(ymin = lower, ymax = upper, fill = "All Waves 95% PI"), alpha = 0.3) +
    scale_colour_manual(name = "", 
                        values = c("Winter 2020" = "#F8766D", "Delta" = "#00BA38", 
                                   "Omicron" = "#619CFF", "All Waves" = "black")) + 
    scale_fill_manual(name = "", values = c("All Waves 95% PI" = "lightblue3")) + 
    labs(
      title = "Low Capacity: 10 ICU beds/100,000",
      x = "Service Population Size (Thousands)",
      y = "Predicted Maximum ICU Occupancy (%)"
    ) + 
    theme_bw() +
    ylim(0, 130) +
    xlim(0,xlim_max/1000) +
    theme(
      plot.title = element_text(size = rel(1.5), hjust = 0.5),
      axis.text.x = element_text(size = rel(1.5)),
      axis.text.y = element_text(size = rel(1.5)),
      axis.title.x = element_text(size = 14),
      axis.title.y = element_text(size = 14),
      legend.title = element_text(size = 14),
      legend.text = element_text(size = 12),
      legend.position = "none",
      panel.grid.minor = element_blank(),
      panel.grid.major = element_blank()
    )
  
  High <- ggplot(plot_data2 %>% filter(Capacity_std == Cap_high,Population<xlim_max), aes(x = Population / 1000)) + 
    geom_line(aes(y = wave2_predicted, col = "Winter 2020"), size = 1.5) + 
    geom_line(aes(y = delta_predicted, col = "Delta"), size = 1.5) + 
    geom_line(aes(y = omicron_predicted, col = "Omicron"), size = 1.5) + 
    geom_line(aes(y = all_predicted, col = "All Waves"), linetype = "dashed", size = 2) + 
    geom_ribbon(data = plot_data %>% filter(Capacity_std == Cap_high, Population<xlim_max), 
                aes(ymin = lower, ymax = upper, fill = "All Waves"), alpha = 0.3) + 
    scale_colour_manual(
      name = "Mean", 
      values = c("Winter 2020" = "#F8766D", "Delta" = "#00BA38", 
                 "Omicron" = "#619CFF", "All Waves" = "black")
    ) + 
    scale_fill_manual(
      name = "95% Prediction Interval", 
      values = c("All Waves" = "lightblue3")
    ) + 
    labs(
      title = "High Capacity: 35 ICU beds/100,000",
      x = "Service Population Size (Thousands)",
      y = "Predicted Maximum ICU Occupancy (%)"
    ) + 
    theme_bw() +
    xlim(0, xlim_max/1000) +
    ylim(0, 130) +
    theme(
      plot.title = element_text(size = rel(1.5), hjust = 0.5),
      axis.text.x = element_text(size = rel(1.5)),
      axis.text.y = element_text(size = rel(1.5)),
      axis.title.x = element_text(size = 14),
      axis.title.y = element_text(size = 14),
      legend.title = element_text(size = 14),
      legend.text = element_text(size = 12),
      legend.position = "right",
      panel.grid.minor = element_blank(),
      panel.grid.major = element_blank()
    )
  
  # Variance function plot
  var_params <- hierarchical_lme$modelStruct$varStruct
  delta <- coef(var_params)["power"]
  sigma_sq <- summary(hierarchical_lme)$sigma^2
  
  predicted_var <- sigma_sq * abs(HSA_overall_std$Population)^(2*delta)
  lower_ci <- -1.96*sqrt(predicted_var)
  upper_ci <- 1.96*sqrt(predicted_var)
  
  plot_data_var <- data.frame(
    Population = HSA_overall_std$Population,
    Residuals = resid(hierarchical_lme),
    LowerCI = lower_ci,
    UpperCI = upper_ci
  )
  
  Variance_function <- ggplot(plot_data_var %>% filter(Population<xlim_max), aes(x = Population/1000, y = Residuals)) +
    geom_ribbon(aes(ymin = LowerCI, ymax = UpperCI),
                fill = "lightblue", alpha = 0.3) +
    geom_point(alpha = 0.6) +
    xlim(0, xlim_max/1000) +
    labs(
      x = "Service Population Size (Thousands)",
      y = "Residuals"
    ) +
    theme_bw() +
    theme(
      plot.title = element_text(size = rel(1.5), hjust = 0.5),
      axis.text.x = element_text(size = rel(1.5)),
      axis.text.y = element_text(size = rel(1.5)),
      axis.title.x = element_text(size = 14),
      axis.title.y = element_text(size = 14),
      legend.title = element_text(size = 14),
      legend.text = element_text(size = 12),
      legend.position = "right",
      panel.grid.minor = element_blank(),
      panel.grid.major = element_blank()
    )
  
  # Combine plots
  top <- (Low + High) + 
    plot_layout(axes = "collect") +
    plot_annotation(
      theme = theme(
        legend.position = "right",
        legend.box = "vertical",
        legend.box.spacing = unit(0.5, "cm"),
        legend.spacing.x = unit(1, "cm"),
        legend.key.width = unit(1.5, "cm"),
        legend.text = element_text(size = 12)
      )
    )
  
  combined <- top / plot_spacer() / Variance_function +
    plot_layout(heights = c(1, 0.07, 1))
  
  return(list(Low = Low, High = High, Variance = Variance_function, 
              top = top, combined = combined))
}

# Function to generate volatility figure (Figure 2)
generate_volatility_figure <- function(HSA_df_long, HSA_df_jump, ICU_occ) {
  
  # Example time series plots
  HSA_ICU_155OB <- data.frame(ICU_cap = ICU_occ$HSA155, Date = ICU_occ$Date)
  HSA_ICU_155MA <- data.frame(ICU_cap = slide_mean(HSA_ICU_155OB$ICU_cap, before=1, after=1), 
                              Date = ICU_occ$Date)
  #Filter Dates
  HSA_ICU_155OB<-HSA_ICU_155OB %>% filter(Date>as.Date("10/01/2020", '%m/%d/%Y'), Date<as.Date("07/01/2022", '%m/%d/%Y'))
  HSA_ICU_155MA<-HSA_ICU_155MA %>% filter(Date>as.Date("10/01/2020", '%m/%d/%Y'), Date<as.Date("07/01/2022", '%m/%d/%Y'))
  
  
  p1 <- ggplot() +
    geom_area(data = HSA_ICU_155MA, aes(x = Date, y = ICU_cap*100, fill = "Moving_Average")) +
    geom_line(data = HSA_ICU_155OB, aes(x = Date, y = ICU_cap*100, color = "Observed"), linewidth = 0.5) +
    theme_bw() +
    scale_y_continuous(limits = c(0, 85), expand = c(0, 0)) +
    ylab("ICU Occupancy\nby COVID Patients (%)") +
    labs(title = "HSA 155: Bay-Jackson, FL") +
    theme(
      plot.title = element_text(size = 16, hjust = 0.5),
      strip.background = element_blank(),
      strip.text = element_text(size = 16),
      legend.text = element_text(size = 12),
      legend.title = element_text(size = 14),
      legend.key.width = unit(1, 'cm'),
      axis.text.x = element_text(size = rel(1.5)),
      axis.text.y = element_text(size = rel(1.5)),
      axis.title.x = element_text(size = 14),
      axis.title.y = element_text(size = 14),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      legend.position = c(0.8, 0.8)
    ) +
    scale_x_date(date_labels = "%b %y", date_breaks = "year") +
    scale_color_manual(" ", values = c(Observed = "black")) +  
    scale_fill_manual(" ", values = c(Moving_Average = "lightblue3"),
                      labels = c(Moving_Average = "Moving Average"))
  
  HSA_ICU_357OB <- data.frame(ICU_cap = ICU_occ$HSA357, Date = ICU_occ$Date)
  HSA_ICU_357MA <- data.frame(ICU_cap = slide_mean(HSA_ICU_357OB$ICU_cap, before=1, after=1), 
                              Date = ICU_occ$Date)
  
  #Filter Dates
  HSA_ICU_357OB<-HSA_ICU_357OB %>% filter(Date>as.Date("10/01/2020", '%m/%d/%Y'), Date<as.Date("07/01/2022", '%m/%d/%Y'))
  HSA_ICU_357MA<-HSA_ICU_357MA %>% filter(Date>as.Date("10/01/2020", '%m/%d/%Y'), Date<as.Date("07/01/2022", '%m/%d/%Y'))
  
  
  p2 <- ggplot() +
    geom_area(data = HSA_ICU_357MA, aes(x = Date, y = ICU_cap*100, fill = "Moving_Average")) +
    geom_line(data = HSA_ICU_357OB, aes(x = Date, y = ICU_cap*100, color = "Observed"), linewidth = 0.5) +
    scale_y_continuous(limits = c(0, 85), expand = c(0, 0)) +
    theme_bw() +
    ylab("ICU Occupancy\nby COVID Patients (%)") +
    labs(title = "HSA 357: Ashland-Sawyer, WI") +
    theme(
      plot.title = element_text(size = 16, hjust = 0.5),
      strip.background = element_blank(),
      strip.text = element_text(size = 16),
      legend.text = element_text(size = 12),
      legend.title = element_text(size = 14),
      legend.key.width = unit(1, 'cm'),
      axis.text.x = element_text(size = rel(1.5)),
      axis.text.y = element_text(size = rel(1.5)),
      axis.title.x = element_text(size = 14),
      axis.title.y = element_text(size = 14),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      legend.position = "none"
    ) +
    scale_x_date(date_labels = "%b %y", date_breaks = "year") +
    scale_color_manual(" ", values = c(Observed = "black")) +  
    scale_fill_manual(" ", values = c(Moving_Average = "lightblue3"),
                      labels = c(Moving_Average = "Moving Average"))
  
  # Power law plots
  power_laws <- ggplot(data = HSA_df_long %>% 
                         filter(Population > 30000, volatility > 0)) + 
    geom_point(mapping = aes(x = Population, y = volatility), 
               size = 1.2, col = "gray55", alpha = 0.5) + 
    geom_smooth(aes(x = Population, y = volatility), 
                method = 'lm', formula = y ~ x, se = FALSE, 
                col = "black", linewidth = 0.5) + 
    geom_point(data = HSA_df_long %>% filter(HSA == 155), 
               mapping = aes(x = Population, y = volatility), 
               color = "black", size = 3) + 
    geom_text(data = HSA_df_long %>% filter(HSA == 155), 
              mapping = aes(x = Population, y = volatility, label = "HSA 155"), 
              color = "black", size = 5, hjust = +1.3, vjust = +1.3, fontface = 2) + 
    geom_point(data = HSA_df_long %>% filter(HSA == 357), 
               mapping = aes(x = Population, y = volatility), 
               color = "black", size = 3) + 
    geom_text(data = HSA_df_long %>% filter(HSA == 357), 
              mapping = aes(x = Population, y = volatility, label = "HSA 357"), 
              color = "black", size = 5, hjust = -0.1, vjust = -0.5, fontface = 2) + 
    scale_x_continuous(trans = 'log10',
                       labels = scales::scientific) + 
    scale_y_continuous(trans = 'log10') + 
    labs(y = 'Volatility of ICU Occupancy\nby COVID patients', 
         x = 'Population') + 
    theme_bw() + 
    facet_wrap(~wave) +
    theme(
      plot.title = element_text(size = rel(1.2), hjust = 0.5),
      legend.position = "none",
      strip.background = element_blank(),
      strip.text.x = element_text(size = 18),
      legend.text = element_text(size = rel(1.2)),
      legend.title = element_text(size = rel(1.8)),
      axis.text.x = element_text(size = rel(1.5)),
      axis.text.y = element_text(size = rel(1.5)),
      axis.title.x = element_text(size = 14),
      axis.title.y = element_text(size = 14),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank()
    ) +
    geom_text(data = HSA_df_long, 
              aes(x = 1*10^6, y = 20, label = equation), 
              fontface = "bold", size = 6, parse = TRUE, family = "serif")
  
  # Jump plots
  jumps <- ggplot(data = HSA_df_jump %>% filter(Population > 30000, Jump > 0)) + 
    geom_point(mapping = aes(x = Population, y = Jump*100), 
               size = 1.2, col = "gray55", alpha = 0.5) + 
    geom_point(data = HSA_df_jump %>% filter(HSA == 155), 
               mapping = aes(x = Population, y = Jump*100), 
               color = "black", size = 3) +
    geom_text(data = HSA_df_jump %>% filter(HSA == 155), 
              mapping = aes(x = Population, y = Jump*100, label = "HSA 155"), 
              color = "black", size = 5, hjust = -0.1, vjust = -0.5, fontface = 2) + 
    geom_point(data = HSA_df_jump %>% filter(HSA == 357), 
               mapping = aes(x = Population, y = Jump*100), 
               color = "black", size = 3) + 
    geom_text(data = HSA_df_jump %>% filter(HSA == 357), 
              mapping = aes(x = Population, y = Jump*100, label = "HSA 357"), 
              color = "black", size = 5, hjust = -0.1, vjust = -0.5, fontface = 2) + 
    scale_x_continuous(trans = 'log10',
                       labels = scales::scientific) + 
    labs(y = 'Maximum 7-day Change in\nCOVID ICU Occupancy (%)', 
         x = 'Population') + 
    theme_bw() +  
    facet_wrap(~wave) +
    theme(
      plot.title = element_text(size = rel(1.2), hjust = 0.5),
      legend.position = "none",
      strip.background = element_blank(),
      strip.text = element_blank(),
      legend.text = element_text(size = rel(1.2)),
      legend.title = element_text(size = rel(1.8)),
      axis.text.x = element_text(size = rel(1.5)),
      axis.text.y = element_text(size = rel(1.5)),
      axis.title.x = element_text(size = 14),
      axis.title.y = element_text(size = 14),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank()
    )
  
  # Combine all plots
  Volatility_plot <- (
    (p2 | p1) + plot_layout(axis_titles = "collect", axes = "collect_y")
  ) / 
    plot_spacer() /
    power_laws /
    plot_spacer() /
    jumps +
    plot_layout(heights = c(1, 0.07, 1, 0.07, 1))
  
  return(Volatility_plot)
}

# Function to generate temporal clustering figure (Figure 3)
generate_temporal_clustering_figure <- function(total, predictions_long, indiv_total, 
                                                total_peak_density, wave_means,hsa_plots,xlim_max=1000000) {
  
  bin_width <- 20000
  
  # Temporal clustering plots for each wave
  p1_wave2 <- ggplot() +
    geom_point(
      data = total %>%
        filter(wave == "Winter 2020", !is.na(diff_coef),Population<xlim_max) %>%
        mutate(bin = floor(Population / bin_width)) %>%
        group_by(bin) %>%
        slice_sample(n = 200) %>%
        ungroup(),
      aes(x = Population / 10^3, y = diff_coef, color = pool_size),
      alpha = 0.5
    ) +
    geom_line(data = predictions_long %>% filter(wave == "Winter 2020",Population<xlim_max), 
              aes(x = Population/10^3, y = value, linetype = quantile), 
              color = "black", size = 1) +
    labs(
      x = "Service Population Size (Thousands)",
      y = expression("Temporal Clustering of Demand" ~ bgroup("(", CV[Pool] - CV[HSA], ")")),
      linetype = "Quantile",
      title = "Winter 2020"
    ) +
    ylim(-0.5, 1) +
    xlim(0, xlim_max/1000) +
    scale_linetype_manual(
      values = c("0.1" = "dotted", "0.5" = "solid", "0.9" = "dotted")) +
    theme_bw() +
    scale_color_gradientn(
      colors = c("lightblue", "blue"),
      name = "n hospitals\nin pool",
      limits = c(0, 10),
      guide = guide_colorbar(
        title.position = "top",
        title.vjust = 5
      )) +
    theme(
      plot.title = element_text(size = 16, hjust = 0.5),
      strip.background = element_blank(),
      strip.text = element_text(size = 16),
      legend.position = "none",
      legend.text = element_text(size = 12),
      legend.title = element_text(size = 14),
      axis.text.x = element_text(size = rel(1.5)),
      axis.text.y = element_text(size = rel(1.5)),
      axis.title.x = element_text(size = 14),
      axis.title.y = element_text(size = 14),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank()
    )
  
  p1_delta <- ggplot() +
    geom_point(
      data = total %>%
        filter(wave == "Delta", !is.na(diff_coef),Population<xlim_max) %>%
        mutate(bin = floor(Population / bin_width)) %>%
        group_by(bin) %>%
        slice_sample(n = 200) %>%
        ungroup(),
      aes(x = Population / 10^3, y = diff_coef, color = pool_size),
      alpha = 0.5
    ) +
    geom_line(data = predictions_long %>% filter(wave == "Delta",Population<xlim_max), 
              aes(x = Population/10^3, y = value, linetype = quantile), 
              color = "black", size = 1) +
    labs(
      x = "Service Population Size (Thousands)",
      y = expression("Temporal Clustering of Demand" ~ bgroup("(", CV[Pool] - CV[HSA], ")")),
      linetype = "Quantile",
      title = "Delta"
    ) +
    ylim(-0.5, 1) +
    xlim(0, xlim_max/1000) +
    scale_linetype_manual(
      values = c("0.1" = "dotted", "0.5" = "solid", "0.9" = "dotted")) +
    theme_bw() +
    scale_color_gradientn(
      colors = c("lightblue", "blue"),
      name = "n hospitals\nin pool",
      limits = c(0, 10),
      guide = guide_colorbar(
        title.position = "top",
        title.vjust = 5
      )) +
    theme(
      plot.title = element_text(size = 16, hjust = 0.5),
      strip.background = element_blank(),
      strip.text = element_text(size = 16),
      legend.position = "none",
      legend.text = element_text(size = 12),
      legend.title = element_text(size = 14),
      axis.text.x = element_text(size = rel(1.5)),
      axis.text.y = element_text(size = rel(1.5)),
      axis.title.x = element_text(size = 14),
      axis.title.y = element_text(size = 14),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank()
    )
  
  p1_omicron <- ggplot() +
    geom_point(
      data = total %>%
        filter(wave == "Omicron", !is.na(diff_coef),Population<xlim_max) %>%
        mutate(bin = floor(Population / bin_width)) %>%
        group_by(bin) %>%
        slice_sample(n = 200) %>%
        ungroup(),
      aes(x = Population / 10^3, y = diff_coef, color = pool_size),
      alpha = 0.5
    ) +
    geom_line(
      data = predictions_long %>% filter(wave == "Omicron",Population<xlim_max),
      aes(x = Population / 10^3, y = value, linetype = quantile),
      color = "black", size = 1
    ) +
    labs(
      x = "Service Population Size (Thousands)",
      y = expression("Temporal Clustering of Demand" ~ bgroup("(", CV[Pool] - CV[HSA], ")")),
      linetype = "Quantile",
      title = "Omicron"
    ) +
    ylim(-0.5, 1) +
    xlim(0, xlim_max/1000) +
    scale_linetype_manual(
      values = c("0.1" = "dotted", "0.5" = "solid", "0.9" = "dotted")
    ) +
    theme_bw() +
    scale_color_gradientn(
      colors = c("lightblue", "blue"),
      name = "n hospitals\nin pool",
      limits = c(0, 10),
      guide = guide_colorbar(
        title.position = "top",
        title.vjust = 5
      )
    ) +
    theme(
      plot.title = element_text(size = 16, hjust = 0.5),
      strip.background = element_blank(),
      strip.text = element_text(size = 16),
      legend.position = "right",
      legend.text = element_text(size = 12),
      legend.title = element_text(size = 14),
      axis.text.x = element_text(size = rel(1.5)),
      axis.text.y = element_text(size = rel(1.5)),
      axis.title.x = element_text(size = 14),
      axis.title.y = element_text(size = 14),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank()
    )
  
  # Effect pooling plot
  Effect_Pooling <- ggplot(indiv_total, aes(x = coef_var, y = diff_coef, color = wave)) +
    geom_point(alpha = 0.2) +       
    geom_smooth(size = 1.5, span = 1, se = FALSE, fullrange = TRUE) +
    labs(
      y = expression("Benefit to Hospital from Pooling" ~ bgroup("(", CV[Hosp] - CV[HSA], ")")),
      x = expression("Temporal Clustering of Hospital Demand"~ bgroup("(", CV[Hosp], ")"))
    ) +
    theme_bw() +  
    theme(
      plot.title = element_text(size = rel(1.5), hjust = 0.5),
      strip.background = element_blank(),
      strip.text.x = element_blank(),
      legend.position = c(0.2, 0.8),
      legend.text = element_text(size = 12),
      legend.title = element_blank(),
      axis.text.x = element_text(size = rel(1.5)),
      axis.text.y = element_text(size = rel(1.5)),
      axis.title.x = element_text(size = 14),
      axis.title.y = element_text(size = 14),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      plot.tag = element_text(size = 14, face = "bold")
    )
  
  # Peak density plot
  peak_density <- ggplot(total_peak_density, aes(x = timing_difference)) +
    geom_density(aes(fill = wave, col = wave), bw = 0.5, linewidth = 1, alpha = 0.2) +
    geom_vline(data = wave_means,
               aes(xintercept = mean_timing, col = wave),
               linetype = "dashed", linewidth = 2,
               show.legend = FALSE) +
    labs(
      x = "Difference in Peak Timing\nBetween Hospitals in HSA (weeks)",
      y = "Density"
    ) +
    guides(
      fill = guide_legend(override.aes = list(alpha = 0.5, linewidth = 0.4)),
      color = "none"
    ) +
    theme_bw() +
    theme(
      plot.title = element_text(size = rel(1.5), hjust = 0.5),
      legend.position = "right",
      legend.text = element_text(size = 12),
      legend.title = element_blank(),
      legend.key.size = unit(1, 'cm'),
      legend.key.height = unit(1, 'cm'),
      legend.key.width = unit(1, 'cm'),
      axis.text.x = element_text(size = rel(1.5)),
      axis.text.y = element_text(size = rel(1.5)),
      axis.title.x = element_text(size = 14),
      axis.title.y = element_text(size = 14),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      plot.tag.position = c(0, 0.95),
      plot.tag = element_text(size = 14, face = "bold")
    )
  
  
  
  # Extract HSA example plots
  pool_example_wave2 <- hsa_plots$wave2
  pool_example_delta <- hsa_plots$delta
  pool_example_omicron <- hsa_plots$omicron
  
  # Combine all plots (now including HSA examples) (now including HSA examples)
  diversification_plot <- (
    (p1_wave2 + p1_delta + p1_omicron +
       plot_layout(axis_titles = "collect", axes = "collect_y")) /
      plot_spacer() /
      (Effect_Pooling + peak_density) /
      plot_spacer() /
      (pool_example_wave2 + pool_example_delta + pool_example_omicron +
         plot_layout(axis_titles = "collect", axes = "collect_y"))
  ) +
    plot_layout(heights = c(1, 0.07, 1, 0.07, 1))
  
  return(diversification_plot)
}

# Function to generate health effects heatmap (Figure 4)
generate_health_effects_heatmap <- function(heatmap_data_wave2, heatmap_data_delta, 
                                            heatmap_data_omicron, heatmap_data_10th_wave2, 
                                            heatmap_data_10th_delta, heatmap_data_10th_omicron,
                                            median_min, median_max, quantile_min, quantile_max) {
  
  # Define color scales
  median_scale <- scale_fill_gradient(
    low = "#435B8C",
    high = "white",
    limits = c(median_min, median_max),
    name = "Change in COVID\nICU Mortality (%)"
  )
  
  quantile_scale <- scale_fill_gradient(
    low = "#762A83",
    high = "white",
    limits = c(quantile_min, quantile_max),
    name = "Change in COVID\nICU Mortality (%)"
  )
  
  # Function to create median heatmap
  create_heatmap <- function(data, title) {
    p <- ggplot(data %>% filter(!is.na(Population_bin)),
                aes(x = as.character(pool_size), y = Population_bin, 
                    fill = Mortality_change_median)) +
      geom_tile() +
      labs(x = "Number of Hospitals in Pool",
           y = "Mean Population\nper Hospital (thousands)",
           title = title) +
      theme_minimal() +
      theme(plot.title = element_text(size = rel(1.5), hjust = 0.5),
            legend.key.height = unit(2, "cm"),
            legend.position = "bottom",
            legend.text = element_text(size = 14),
            legend.title = element_text(size = 14),
            axis.text.x = element_text(size = rel(1.5)),
            axis.text.y = element_text(size = rel(1.5)),
            axis.title.x = element_text(size = 14),
            axis.title.y = element_text(size = 14))
    
    return(p + median_scale)
  }
  
  # Function to create 10th quantile heatmap
  create_heatmap_qu10 <- function(data, title) {
    p <- ggplot(data %>% filter(!is.na(Population_bin)),
                aes(x = as.character(pool_size), y = Population_bin, 
                    fill = Mortality_change_qu10)) +
      geom_tile() +
      labs(x = "Number of Hospitals in Pool",
           y = "Mean Population\nper Hospital (thousands)",
           title = title) +
      theme_minimal() +
      theme(plot.title = element_text(size = rel(1.5), hjust = 0.5),
            legend.key.height = unit(2, "cm"),
            legend.position = "right",
            legend.text = element_text(size = 14),
            legend.title = element_text(size = 14),
            axis.text.x = element_text(size = rel(1.5)),
            axis.text.y = element_text(size = rel(1.5)),
            axis.title.x = element_text(size = 14),
            axis.title.y = element_text(size = 14))
    
    return(p + quantile_scale)
  }
  
  # Create individual heatmaps without legends
  heatmap_wave2 <- create_heatmap(heatmap_data_wave2, "Winter 2020") + 
    theme(legend.position = "none")
  heatmap_delta <- create_heatmap(heatmap_data_delta, "Delta") + 
    theme(legend.position = "none")
  heatmap_omicron <- create_heatmap(heatmap_data_omicron, "Omicron") + 
    theme(legend.position = "none")
  
  heatmap_10th_wave2 <- create_heatmap_qu10(heatmap_data_10th_wave2, "Winter 2020") + 
    theme(legend.position = "none")
  heatmap_10th_delta <- create_heatmap_qu10(heatmap_data_10th_delta, "Delta") + 
    theme(legend.position = "none")
  heatmap_10th_omicron <- create_heatmap_qu10(heatmap_data_10th_omicron, "Omicron") + 
    theme(legend.position = "none")
  
  # Combine panels
  Three_waves_heatmap <- (heatmap_wave2 + heatmap_delta + heatmap_omicron) + 
    plot_layout(axis_titles = "collect", axes = "collect_y")
  
  Three_waves_10th_heatmap <- (heatmap_10th_wave2 + heatmap_10th_delta + heatmap_10th_omicron) + 
    plot_layout(axis_titles = "collect", axes = "collect_y")
  
  # Create titles
  title1 <- ggdraw() + draw_label("Median Effect", fontface = "bold", size = 22)
  title2 <- ggdraw() + draw_label("Best-Case Effect (10th Quantile)", fontface = "bold", size = 22)
  
  # Create legend plots
  median_legend_data <- data.frame(
    x = 1, 
    y = 1:100, 
    z = seq(median_min, median_max, length.out = 100)
  )
  
  median_legend_plot <- ggplot(median_legend_data, aes(x = x, y = y, fill = z)) +
    geom_tile() +
    median_scale +
    theme_void() +
    theme(legend.position = "right",
          legend.key.height = unit(1, "cm"),
          legend.key.width = unit(1, "cm"))
  
  quantile_legend_data <- data.frame(
    x = 1, 
    y = 1:100, 
    z = seq(quantile_min, quantile_max, length.out = 100)
  )
  
  quantile_legend_plot <- ggplot(quantile_legend_data, aes(x = x, y = y, fill = z)) +
    geom_tile() +
    quantile_scale +
    theme_void() +
    theme(legend.position = "right",
          legend.key.height = unit(1, "cm"),
          legend.key.width = unit(1, "cm"))
  
  # Extract legends
  median_legend <- get_legend(median_legend_plot)
  quantile_legend <- get_legend(quantile_legend_plot)
  
  # Combine with titles and legends
  top_panel <- plot_grid(title1, Three_waves_heatmap, ncol = 1, rel_heights = c(0.1, 1))
  bottom_panel <- plot_grid(title2, Three_waves_10th_heatmap, ncol = 1, rel_heights = c(0.1, 1))
  
  top_with_legend <- plot_grid(top_panel, median_legend, ncol = 2, rel_widths = c(3, 0.5))
  bottom_with_legend <- plot_grid(bottom_panel, quantile_legend, ncol = 2, rel_widths = c(3, 0.5))
  
  # Final combination
  heatmap_combined <- plot_grid(top_with_legend, bottom_with_legend, ncol = 1)
  
  return(heatmap_combined)
}

# Function to generate sample count heatmap (Figure S2)
generate_sample_count_heatmap <- function(heatmap_data_wave2, heatmap_data_delta, 
                                          heatmap_data_omicron) {
  
  create_heatmap_count <- function(data, title) {
    p <- ggplot(data,
                aes(x = as.character(pool_size), y = Population_bin)) +
      geom_tile(fill = "white", color = "gray80") +
      geom_text(aes(label = count_per_group), size = 4) +
      labs(x = "Number of Hospitals in Pool",
           y = "Mean Population\nper Hospital (thousands)",
           title = title) +
      theme_minimal() +
      theme(plot.title = element_text(size = rel(1.5), hjust = 0.5),
            axis.text.x = element_text(size = rel(1.5)),
            axis.text.y = element_text(size = rel(1.5)),
            axis.title.x = element_text(size = 14),
            axis.title.y = element_text(size = 14))
    
    return(p)
  }
  
  heatmap_wave2_count <- create_heatmap_count(heatmap_data_wave2, "Winter 2020") + 
    theme(legend.position = "none")
  heatmap_delta_count <- create_heatmap_count(heatmap_data_delta, "Delta") + 
    theme(legend.position = "none")
  heatmap_omicron_count <- create_heatmap_count(heatmap_data_omicron, "Omicron") + 
    theme(legend.position = "none")
  
  count_plot <- heatmap_wave2_count + heatmap_delta_count + heatmap_omicron_count +
    plot_layout(axis_titles = "collect", axes = "collect_y")
  
  return(count_plot)
}


# Function to create empirical funnel plots
# Shows quantile regression funnels for maximum ICU occupancy vs population

generate_empirical_funnel <- function(HSA_df, ICU_occ, example_HSA = 155, 
                                      pop_min = 30000, pop_max = 3000000) {
  
  # Filter HSA data
  HSA_df_filtered <- HSA_df %>% 
    filter(Population > pop_min,
           Population < pop_max,
           max_occ_Delta > 0, 
           max_occ_Omicron > 0, 
           max_occ_w2 > 0)
  
  # ========================================
  # Top Panel: Time series for example HSA
  # ========================================
  p1 <- ggplot() +
    geom_line(data = ICU_occ %>% filter(Date>as.Date("2020-11-01"), Date<as.Date("2022-04-28")), aes(x = Date, y = .data[[paste0("HSA", example_HSA)]] * 100)) +
    geom_point(data = HSA_df_filtered %>% filter(HSA == example_HSA), 
               aes(x = Peak_w2, y = max_occ_w2), col = "#F8766D", size = 5) +
    geom_point(data = HSA_df_filtered %>% filter(HSA == example_HSA), 
               aes(x = Peak_Delta, y = max_occ_Delta), col = "#00BA38", size = 5) +
    geom_point(data = HSA_df_filtered %>% filter(HSA == example_HSA), 
               aes(x = Peak_Omicron, y = max_occ_Omicron), col = "#619CFF", size = 5) +
    theme_bw() +
    #xlim(as.Date("2020-11-01"), as.Date("2022-04-28")) +
    labs(title = "Health Service Area 155: Bay, Calhoun, Gulf, Holmes, Jackson and Washington counties FL",
         y = "ICU Occupancy\nby COVID Patients (%)") +
    theme(plot.title = element_text(size = rel(1.5), hjust = 0.5),
          legend.position = "none",
          legend.text = element_text(size = 12),
          legend.title = element_text(size = 14),
          legend.key.width = unit(1, 'cm'),
          axis.text.x = element_text(size = rel(1.5)),
          axis.text.y = element_text(size = rel(1.5)),
          axis.title.x = element_text(size = 14),
          axis.title.y = element_text(size = 14),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank())
  
  # Color scheme for points
  colours3 <- c("HSA 155 Winter 2020" = "#F8766D",
                "HSA 155 Delta" = "#00BA38",
                "HSA 155 Omicron" = "#619CFF",
                "Other HSAs" = "grey55")
  
  # ========================================
  # Winter 2020 Funnel
  # ========================================
  HSA_df_w1 <- HSA_df_filtered %>% 
    filter(max_occ_w2 >= 0, !is.na(max_occ_w2), !is.infinite(max_occ_w2))
  
  # Fit quantile regression model
  model_growth_w1 <- gcrq(max_occ_w2 ~ ps(Population), 
                          tau = c(0.1, 0.5, 0.9), 
                          data = HSA_df_w1)
  
  temp <- model_growth_w1$fitted.values
  HSA_df_w1 <- cbind(HSA_df_w1, temp)
  
  # Prepare long format data for plotting
  HSA_df_w1_long <- data.frame(
    Population = rep(HSA_df_w1$Population, 3),
    Value = c(HSA_df_w1$"0.1", HSA_df_w1$"0.5", HSA_df_w1$"0.9"),
    Quantile = factor(rep(c("0.1", "0.5", "0.9"), each = dim(HSA_df_w1)[1]),
                      levels = c("0.9", "0.5", "0.1"))
  )
  
  w1 <- ggplot(data = HSA_df_w1_long) +
    geom_point(data = HSA_df_w1 %>% filter(HSA != example_HSA), 
               aes(x = Population, y = max_occ_w2, col = "Other HSAs"), 
               size = 2, alpha = 0.35) +
    geom_line(aes(x = Population, y = Value, linetype = Quantile, size = Quantile)) +
    geom_point(data = HSA_df_w1 %>% filter(HSA == example_HSA),
               aes(x = Population, y = max_occ_w2, col = "HSA 155 Winter 2020"), 
               size = 5) +
    scale_linetype_manual(values = c("0.9" = 3, "0.5" = 1.5, "0.1" = 3)) +
    scale_size_manual(values = c("0.9" = 1, "0.5" = 1, "0.1" = 1)) +
    scale_color_manual(values = colours3, breaks = names(colours3)) +
    ylab("Maximum ICU Occupancy\nby COVID Patients (%)") +
    xlab("Population of Health Service Area") +
    xlim(0, pop_max) +
    ylim(0, 130) +
    theme_bw() +
    labs(title = "Winter 2020", linetype = "Quantile", size = "Quantile", color = "Maximums") +
    theme(plot.title = element_text(size = rel(1.5), hjust = 0.5),
          legend.position = "none",
          legend.text = element_text(size = 12),
          legend.title = element_text(size = 14),
          legend.key.width = unit(1, 'cm'),
          axis.text.x = element_text(size = rel(1.5)),
          axis.text.y = element_text(size = rel(1.5)),
          axis.title.x = element_text(size = 14),
          axis.title.y = element_text(size = 14),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank())
  
  # ========================================
  # Delta Funnel
  # ========================================
  HSA_df_Delta <- HSA_df_filtered %>% 
    filter(max_occ_Delta >= 0, !is.na(max_occ_Delta), !is.infinite(max_occ_Delta))
  
  model_growth_Delta <- gcrq(max_occ_Delta ~ ps(Population), 
                             tau = c(0.1, 0.5, 0.9), 
                             data = HSA_df_Delta)
  
  temp <- model_growth_Delta$fitted.values
  HSA_df_Delta <- cbind(HSA_df_Delta, temp)
  
  HSA_df_Delta_long <- data.frame(
    Population = rep(HSA_df_Delta$Population, 3),
    Value = c(HSA_df_Delta$"0.1", HSA_df_Delta$"0.5", HSA_df_Delta$"0.9"),
    Quantile = factor(rep(c("0.1", "0.5", "0.9"), each = dim(HSA_df_Delta)[1]),
                      levels = c("0.9", "0.5", "0.1"))
  )
  
  Delta <- ggplot(data = HSA_df_Delta_long) +
    geom_point(data = HSA_df_Delta %>% filter(HSA != example_HSA), 
               aes(x = Population, y = max_occ_Delta), 
               size = 2, col = "grey55", alpha = 0.35) +
    geom_line(aes(x = Population, y = Value, linetype = Quantile, size = Quantile)) +
    geom_point(data = HSA_df_Delta %>% filter(HSA == example_HSA), 
               aes(x = Population, y = max_occ_Delta, col = "HSA 155 Delta"), 
               size = 5) +
    scale_linetype_manual(values = c("0.9" = 3, "0.5" = 1.5, "0.1" = 3)) +
    scale_size_manual(values = c("0.9" = 1, "0.5" = 1, "0.1" = 1)) +
    scale_color_manual(values = colours3, breaks = names(colours3)) +
    ylab("") +
    xlab("Population of Health Service Area") +
    xlim(0, pop_max) +
    ylim(0, 130) +
    theme_bw() +
    labs(title = "Delta", linetype = "Quantile", size = "Quantile", color = "Maximums") +
    theme(plot.title = element_text(size = rel(1.5), hjust = 0.5),
          legend.position = "none",
          legend.text = element_text(size = 12),
          legend.title = element_text(size = 14),
          legend.key.width = unit(1, 'cm'),
          axis.text.x = element_text(size = rel(1.5)),
          axis.text.y = element_text(size = rel(1.5)),
          axis.title.x = element_text(size = 14),
          axis.title.y = element_text(size = 14),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank())
  
  # ========================================
  # Omicron Funnel (with legend)
  # ========================================
  HSA_df_Omicron <- HSA_df_filtered %>% 
    filter(max_occ_Omicron >= 0, !is.na(max_occ_Omicron), !is.infinite(max_occ_Omicron))
  
  model_growth_Omicron <- gcrq(max_occ_Omicron ~ ps(Population), 
                               tau = c(0.1, 0.5, 0.9), 
                               data = HSA_df_Omicron)
  
  temp <- model_growth_Omicron$fitted.values
  HSA_df_Omicron <- cbind(HSA_df_Omicron, temp)
  
  HSA_df_Omicron_long <- data.frame(
    Population = rep(HSA_df_Omicron$Population, 3),
    Value = c(HSA_df_Omicron$"0.1", HSA_df_Omicron$"0.5", HSA_df_Omicron$"0.9"),
    Quantile = factor(rep(c("0.1", "0.5", "0.9"), each = dim(HSA_df_Omicron)[1]),
                      levels = c("0.9", "0.5", "0.1"))
  )
  
  Omicron <- ggplot(data = HSA_df_Omicron_long) +
    geom_point(data = HSA_df_Omicron %>% filter(HSA != example_HSA), 
               aes(x = Population, y = max_occ_Omicron, col = "Other HSAs"), 
               size = 2, alpha = 0.35) +
    geom_line(aes(x = Population, y = Value, linetype = Quantile, size = Quantile)) +
    # Add invisible points for legend
    geom_point(data = HSA_df_Delta %>% filter(HSA == example_HSA), 
               aes(x = Population, y = max_occ_Delta, col = "HSA 155 Delta"),
               alpha = 0, size = 5) +
    geom_point(data = HSA_df_w1 %>% filter(HSA == example_HSA), 
               aes(x = Population, y = max_occ_w2, col = "HSA 155 Winter 2020"), 
               alpha = 0, size = 5) +
    geom_point(data = HSA_df_Omicron %>% filter(HSA == example_HSA), 
               aes(x = Population, y = max_occ_Omicron, col = "HSA 155 Omicron"), 
               size = 5) +
    scale_linetype_manual(values = c("0.9" = 3, "0.5" = 1.5, "0.1" = 3)) +
    scale_size_manual(values = c("0.9" = 1, "0.5" = 1, "0.1" = 1)) +
    guides(color = guide_legend(override.aes = list(alpha = 1, size = 5))) +
    scale_color_manual(values = colours3, breaks = names(colours3)) +
    ylab("") +
    xlab("Population of Health Service Area") +
    xlim(0, pop_max) +
    ylim(0, 130) +
    theme_bw() +
    labs(title = "Omicron", linetype = "Quantile", size = "Quantile", color = "Maximums") +
    theme(plot.title = element_text(size = rel(1.5), hjust = 0.5),
          legend.position = "right",
          legend.text = element_text(size = 12),
          legend.title = element_text(size = 14),
          legend.key.width = unit(1, 'cm'),
          axis.text.x = element_text(size = rel(1.5)),
          axis.text.y = element_text(size = rel(1.5)),
          axis.title.x = element_text(size = 14),
          axis.title.y = element_text(size = 14),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank())
  
  # ========================================
  # Combine plots
  # ========================================
  
  # Bottom panel: three funnel plots
  bottom <- w1 + Delta + Omicron + plot_layout(axes = "collect")
  
  # Full figure: time series on top, funnels on bottom
  empirical_funnel <- (p1 + theme(legend.position = c(1.1, 0.6))) / bottom
  
  # Return both the full figure and bottom panel
  return(list(
    full_figure = empirical_funnel,
    bottom_panel = bottom,
    time_series = p1,
    winter_2020 = w1,
    delta = Delta,
    omicron = Omicron,
    models = list(
      winter_2020 = model_growth_w1,
      delta = model_growth_Delta,
      omicron = model_growth_Omicron
    )
  ))
}
# Regression Analysis

# Load required data
load("Intermediate_outputs/ICU_occ.txt")
load("Intermediate_outputs/HSA_df.txt")
load("Intermediate_outputs/Capacity.txt")

# Prepare data for regression
HSA_model <- HSA_df %>% 
  select(HSA, max_occ_Delta, max_occ_Omicron, max_occ_w2, Population, 
         CapDelta, Vaccination_Delta, Vaccination_Omicron, CapOmicron, Capw2,
         Over60, Income, Cumul_Delta, Cumul_Omicron, Cumul_w2, Cumul_w2_4w, 
         Cumul_Delta_4w, Cumul_Omicron_4w) %>% 
  filter(Population > 30000)

# Transform data to long format
HSA_overall <- HSA_model %>%
  pivot_longer(
    cols = c(max_occ_Delta, max_occ_Omicron, max_occ_w2),
    names_to = "wave",
    values_to = "peak"
  ) %>% 
  mutate(
    wave = case_when(
      wave == "max_occ_Delta" ~ "Delta",
      wave == "max_occ_Omicron" ~ "Omicron",
      wave == "max_occ_w2" ~ "Wave 2",
      TRUE ~ wave
    ),
    is_Delta = ifelse(wave == "Delta", 1, 0),
    is_Omicron = ifelse(wave == "Omicron", 1, 0),
    vaccination = case_when(
      wave == "Wave 2" ~ 0,
      wave == "Delta" ~ Vaccination_Delta,
      wave == "Omicron" ~ Vaccination_Omicron,
      TRUE ~ NA_real_
    ),
    Cumul = case_when(
      wave == "Wave 2" ~ Cumul_w2_4w,
      wave == "Delta" ~ Cumul_Delta_4w,
      wave == "Omicron" ~ Cumul_Omicron_4w,
      TRUE ~ NA_real_
    ),
    Capacity = case_when(
      wave == "Wave 2" ~ Capw2,
      wave == "Delta" ~ CapDelta,
      wave == "Omicron" ~ CapOmicron,
      TRUE ~ NA_real_
    ),
    inv_sqrt_pop = 1/sqrt(Population)
  ) %>%  
  filter(
    !(HSA == 443 & wave == "Wave 2"),
    !(HSA == 116 & wave == "Omicron"),
    peak > 0
  ) %>% 
  select(-CapDelta, 
         -Vaccination_Delta, -Vaccination_Omicron, -Cumul_Delta, 
         -Cumul_Omicron, -Cumul_w2, -Capw2, -CapDelta, -CapOmicron)

# Standardize variables
HSA_overall_std <- HSA_overall %>%
  mutate(
    inv_sqrt_pop_std = (inv_sqrt_pop - mean(inv_sqrt_pop, na.rm = TRUE)) / sd(inv_sqrt_pop, na.rm = TRUE),
    Cumul_std = (Cumul - mean(Cumul, na.rm = TRUE)) / sd(Cumul, na.rm = TRUE),
    vaccination_std = (vaccination - mean(vaccination, na.rm = TRUE)) / sd(vaccination, na.rm = TRUE),
    Capacity_std = (Capacity - mean(Capacity, na.rm = TRUE)) / sd(Capacity, na.rm = TRUE),
    Over60_std = (Over60 - mean(Over60, na.rm = TRUE)) / sd(Over60, na.rm = TRUE),
    Income_std = (Income - mean(Income, na.rm = TRUE)) / sd(Income, na.rm = TRUE)
  )

# Fit hierarchical mixed effects model
print("Fitting mixed effects model...")
hierarchical_lme <- lme(
  peak ~ inv_sqrt_pop_std + Cumul_std + vaccination_std +
    Capacity_std + inv_sqrt_pop_std*Capacity_std + Over60_std + Income_std + 
    is_Delta + is_Omicron,
  random = ~ 1 | HSA,
  weights = varPower(form = ~Population),
  data = HSA_overall_std
)

print("Mixed effects model summary:")
print(summary(hierarchical_lme))

# Extract variance parameters
var_params <- hierarchical_lme$modelStruct$varStruct
delta <- coef(var_params)["power"]
sigma_sq <- summary(hierarchical_lme)$sigma^2

# Fit individual wave models
print("Fitting Wave 2 model...")
wave2_model_weighted <- gls(
  peak ~ inv_sqrt_pop_std + Cumul_std +
    Capacity_std + inv_sqrt_pop_std*Capacity_std + Over60_std + Income_std,
  data = HSA_overall_std %>% filter(wave == "Wave 2"),
  weights = varPower(form = ~ Population)
)
print(summary(wave2_model_weighted))

print("Fitting Delta model...")
delta_model_weighted <- gls(
  peak ~ inv_sqrt_pop_std + Cumul_std +
    Capacity_std + inv_sqrt_pop_std*Capacity_std + Over60_std + 
    vaccination_std + Income_std,
  data = HSA_overall_std %>% filter(wave == "Delta"),
  weights = varPower(form = ~ Population)
)
print(summary(delta_model_weighted))

print("Fitting Omicron model...")
omicron_model_weighted <- gls(
  peak ~ inv_sqrt_pop_std + Cumul_std +
    Capacity_std + inv_sqrt_pop_std*Capacity_std + Over60_std + 
    vaccination_std + Income_std,
  data = HSA_overall_std %>% filter(wave == "Omicron"),
  weights = varPower(form = ~ Population)
)
print(summary(omicron_model_weighted))

# Save model objects for later use
save(hierarchical_lme, wave2_model_weighted, delta_model_weighted, 
     omicron_model_weighted, HSA_overall, HSA_overall_std,
     file = "Results/regression_models.RData")

print("Regression analysis complete. Models saved to Results/regression_models.RData")

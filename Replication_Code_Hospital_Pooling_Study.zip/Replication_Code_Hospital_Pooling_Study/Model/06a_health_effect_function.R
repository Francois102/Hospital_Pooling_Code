# Functions for health effect calculations

# Helper function for random combinations (if not already loaded)
if (!exists("generate_random_combinations")) {
  generate_random_combinations <- function(elements, k, n_samples) {
    combinations <- vector("list", n_samples)
    for (i in seq_len(n_samples)) {
      combinations[[i]] <- sample(elements, k, replace = FALSE)
    }
    combinations
  }
}

# Main function to calculate pooling health effects
Pooling_health_effect <- function(data, Risk_ratios) {
  results <- data.frame()
  unique_HSAs <- unique(data$HSA)
  
  for (i in 1:length(unique_HSAs)) {
    HSA_data <- data %>%
      filter(HSA == unique_HSAs[i]) %>% 
      group_by(hospital_pk) %>%
      mutate(
        ICU_admissions = slide_mean(ICU_admissions, before = 1, after = 0, 
                                    complete = TRUE, na_rm = TRUE)
      ) %>%
      ungroup()
    
    # Find valid hospitals
    valid_hospitals <- HSA_data %>%
      group_by(hospital_pk) %>%
      reframe(
        total_Bed_sum = sum(median_capacity, na.rm = TRUE),
        total_ICU_admissions = sum(ICU_admissions, na.rm = TRUE),
        .groups = "drop"
      ) %>%
      filter(total_Bed_sum > 0 & total_ICU_admissions > 0) %>%
      pull(hospital_pk)
    
    # Process different pool sizes
    for (pool_size in 2:6) {
      if (length(valid_hospitals) <= pool_size) next
      
      # Generate combinations
      if (choose(length(valid_hospitals), pool_size) > 300) {
        hospital_combinations <- generate_random_combinations(valid_hospitals, pool_size, 300)
      } else {
        hospital_combinations <- combn(valid_hospitals, pool_size, simplify = FALSE)
      }
      
      # Process each pool
      for (pool in hospital_combinations) {
        # Calculate pooled scenario
        pool_data <- HSA_data %>% filter(hospital_pk %in% unlist(pool))
        
        pooled_occupancy <- pool_data %>%
          group_by(collection_week) %>%
          reframe(
            total_ICU_admissions = sum(ICU_admissions, na.rm = TRUE),
            total_Bed_sum = sum(median_capacity, na.rm = TRUE),
            .groups = "drop"
          ) %>%
          mutate(icu_occupancy_percent = (total_ICU_admissions / total_Bed_sum) * 100)
        
        # Calculate pool population
        Pool_Population <- pool_data %>%
          filter(hospital_pk %in% pool) %>% 
          group_by(hospital_pk) %>%
          slice(1) %>%
          ungroup() %>%
          pull(Hospital_Population) %>%
          sum(na.rm = TRUE)
        
        # Calculate population statistics
        Pop_stats <- pool_data %>% 
          group_by(hospital_pk) %>% 
          ungroup() %>%  
          reframe(
            Median_Pop_hosp = median(unique(Hospital_Population), na.rm = TRUE),
            Min_Pop_hosp = min(unique(Hospital_Population), na.rm = TRUE),
            Max_Pop_hosp = max(unique(Hospital_Population), na.rm = TRUE),
            Mean_Pop_hosp = mean(unique(Hospital_Population), na.rm = TRUE)
          )
        
        # Calculate pooled days by occupancy level
        pooled_days <- pooled_occupancy %>% 
          mutate(occupancy_level = cut(
            icu_occupancy_percent,
            breaks = c(-Inf, 25, 50, 75, 100, Inf),
            labels = c("0-25%", "25-50%", "50-75%", "75-100%", ">100%"),
            right = FALSE
          )) %>%
          group_by(occupancy_level) %>%
          summarise(total_admissions = sum(total_ICU_admissions, na.rm = TRUE), .groups = "drop") %>%
          complete(occupancy_level = c("0-25%", "25-50%", "50-75%", "75-100%", ">100%"), 
                   fill = list(total_admissions = 0)) %>%
          mutate(total_admissions = total_admissions / sum(total_admissions)) %>%
          pivot_wider(names_from = occupancy_level, values_from = total_admissions, values_fill = 0)
        
        # Calculate unpooled scenario
        unpooled_days <- pool_data %>%
          group_by(hospital_pk) %>%
          mutate(icu_occupancy_percent = (ICU_admissions / median_capacity) * 100) %>%
          mutate(occupancy_level = cut(
            icu_occupancy_percent,
            breaks = c(-Inf, 25, 50, 75, 100, Inf),
            labels = c("0-25%", "25-50%", "50-75%", "75-100%", ">100%"),
            right = FALSE
          )) %>%
          ungroup() %>%
          group_by(occupancy_level) %>%
          summarise(total_admissions = sum(ICU_admissions, na.rm = TRUE)) %>%
          complete(occupancy_level = c("0-25%", "25-50%", "50-75%", "75-100%", ">100%"), 
                   fill = list(total_admissions = 0)) %>%
          mutate(total_admissions = total_admissions / sum(total_admissions)) %>%
          pivot_wider(names_from = occupancy_level, values_from = total_admissions, values_fill = 0)
        
        # Calculate mortality effects
        Unpooled <- unpooled_days$`0-25%` * Risk_ratios[1] +
          unpooled_days$`25-50%` * Risk_ratios[2] +
          unpooled_days$`50-75%` * Risk_ratios[3] +
          unpooled_days$`75-100%` * Risk_ratios[4] +
          unpooled_days$`>100%` * Risk_ratios[5]
        
        Pooled <- pooled_days$`0-25%` * Risk_ratios[1] +
          pooled_days$`25-50%` * Risk_ratios[2] +
          pooled_days$`50-75%` * Risk_ratios[3] +
          pooled_days$`75-100%` * Risk_ratios[4] +
          pooled_days$`>100%` * Risk_ratios[5]
        
        # Store results
        results <- rbind(results, data.frame(
          HSA = unique_HSAs[i],
          pool = paste(unlist(pool), collapse = ", "),
          pool_size = pool_size,
          Mortality_change = (Pooled - Unpooled) / Unpooled * 100,
          Pooled_value = Pooled,
          Unpooled_value = Unpooled,
          Population = Pool_Population,
          Mean_Pop = Pop_stats$Mean_Pop_hosp,
          Median_Pop = Pop_stats$Median_Pop_hosp,
          Min_Pop = Pop_stats$Min_Pop_hosp,
          Max_Pop = Pop_stats$Max_Pop_hosp
        ))
      }
    }
  }
  return(results)
}

# Function to count HSAs and facilities
count_HSAs_and_facilities <- function(data) {
  included_HSAs <- c()
  included_hospitals <- c()
  unique_HSAs <- unique(data$HSA)
  
  for (i in 1:length(unique_HSAs)) {
    HSA_data <- data %>%
      filter(HSA == unique_HSAs[i]) %>%
      group_by(hospital_pk) %>%
      mutate(
        ICU_admissions = slide_mean(ICU_admissions, before = 1, after = 0, 
                                    complete = TRUE, na_rm = TRUE)
      ) %>%
      ungroup()
    
    valid_hospitals <- HSA_data %>%
      group_by(hospital_pk) %>%
      reframe(
        total_Bed_sum = sum(median_capacity, na.rm = TRUE),
        total_ICU_admissions = sum(ICU_admissions, na.rm = TRUE),
        .groups = "drop"
      ) %>%
      filter(total_Bed_sum > 0 & total_ICU_admissions > 0) %>%
      pull(hospital_pk)
    
    if (length(valid_hospitals) >= 2) {
      included_HSAs <- c(included_HSAs, unique_HSAs[i])
      included_hospitals <- c(included_hospitals, valid_hospitals)
    }
  }
  
  return(list(
    n_HSAs = length(unique(included_HSAs)),
    n_facilities = length(unique(included_hospitals)),
    HSA_list = unique(included_HSAs),
    facility_list = unique(included_hospitals)
  ))
}